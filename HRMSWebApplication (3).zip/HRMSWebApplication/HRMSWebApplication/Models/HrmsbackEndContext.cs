﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace HRMSWebApplication.Models;

public partial class HrmsbackEndContext : DbContext
{
    public HrmsbackEndContext()
    {
    }

    public HrmsbackEndContext(DbContextOptions<HrmsbackEndContext> options)
        : base(options)
    {
    }

    public virtual DbSet<AllowanceDeduction> AllowanceDeductions { get; set; }

    public virtual DbSet<ApprovalWorkflow> ApprovalWorkflows { get; set; }

    public virtual DbSet<ApprovalWorkflowStep> ApprovalWorkflowSteps { get; set; }

    public virtual DbSet<Attendance> Attendances { get; set; }

    public virtual DbSet<AttendanceCorrectionRequest> AttendanceCorrectionRequests { get; set; }

    public virtual DbSet<AttendanceLog> AttendanceLogs { get; set; }

    public virtual DbSet<AttendanceSource> AttendanceSources { get; set; }

    public virtual DbSet<BonusPolicy> BonusPolicies { get; set; }

    public virtual DbSet<ConsultantContract> ConsultantContracts { get; set; }

    public virtual DbSet<Contract> Contracts { get; set; }

    public virtual DbSet<ContractSalaryType> ContractSalaryTypes { get; set; }

    public virtual DbSet<Currency> Currencies { get; set; }

    public virtual DbSet<DeductionPolicy> DeductionPolicies { get; set; }

    public virtual DbSet<Department> Departments { get; set; }

    public virtual DbSet<Device> Devices { get; set; }

    public virtual DbSet<Employee> Employees { get; set; }

    public virtual DbSet<EmployeeHierarchy> EmployeeHierarchies { get; set; }

    public virtual DbSet<EmployeeNotification> EmployeeNotifications { get; set; }

    public virtual DbSet<EmployeeRole> EmployeeRoles { get; set; }

    public virtual DbSet<EmployeeSkill> EmployeeSkills { get; set; }

    public virtual DbSet<Exception> Exceptions { get; set; }

    public virtual DbSet<FullTimeContract> FullTimeContracts { get; set; }

    public virtual DbSet<HolidayLeave> HolidayLeaves { get; set; }

    public virtual DbSet<HourlySalaryType> HourlySalaryTypes { get; set; }

    public virtual DbSet<Hradministrator> Hradministrators { get; set; }

    public virtual DbSet<Insurance> Insurances { get; set; }

    public virtual DbSet<InternshipContract> InternshipContracts { get; set; }

    public virtual DbSet<LatenessPolicy> LatenessPolicies { get; set; }

    public virtual DbSet<Leave> Leaves { get; set; }

    public virtual DbSet<LeaveDocument> LeaveDocuments { get; set; }

    public virtual DbSet<LeaveEntitlement> LeaveEntitlements { get; set; }

    public virtual DbSet<LeavePolicy> LeavePolicies { get; set; }

    public virtual DbSet<LeaveRequest> LeaveRequests { get; set; }

    public virtual DbSet<LineManager> LineManagers { get; set; }

    public virtual DbSet<ManagerNote> ManagerNotes { get; set; }

    public virtual DbSet<Mission> Missions { get; set; }

    public virtual DbSet<MonthlySalaryType> MonthlySalaryTypes { get; set; }

    public virtual DbSet<Notification> Notifications { get; set; }

    public virtual DbSet<OvertimePolicy> OvertimePolicies { get; set; }

    public virtual DbSet<PartTimeContract> PartTimeContracts { get; set; }

    public virtual DbSet<PayGrade> PayGrades { get; set; }

    public virtual DbSet<Payroll> Payrolls { get; set; }

    public virtual DbSet<PayrollLog> PayrollLogs { get; set; }

    public virtual DbSet<PayrollPeriod> PayrollPeriods { get; set; }

    public virtual DbSet<PayrollPolicy> PayrollPolicies { get; set; }

    public virtual DbSet<PayrollSpecialist> PayrollSpecialists { get; set; }

    public virtual DbSet<Position> Positions { get; set; }

    public virtual DbSet<ProbationLeave> ProbationLeaves { get; set; }

    public virtual DbSet<Reimbursement> Reimbursements { get; set; }

    public virtual DbSet<Role> Roles { get; set; }

    public virtual DbSet<RolePermission> RolePermissions { get; set; }

    public virtual DbSet<SalaryType> SalaryTypes { get; set; }

    public virtual DbSet<ShiftAssignment> ShiftAssignments { get; set; }

    public virtual DbSet<ShiftCycle> ShiftCycles { get; set; }

    public virtual DbSet<ShiftCycleAssignment> ShiftCycleAssignments { get; set; }

    public virtual DbSet<ShiftSchedule> ShiftSchedules { get; set; }

    public virtual DbSet<SickLeave> SickLeaves { get; set; }

    public virtual DbSet<Skill> Skills { get; set; }

    public virtual DbSet<SystemAdministrator> SystemAdministrators { get; set; }

    public virtual DbSet<TaxForm> TaxForms { get; set; }

    public virtual DbSet<Termination> Terminations { get; set; }

    public virtual DbSet<VacationLeave> VacationLeaves { get; set; }

    public virtual DbSet<Verification> Verifications { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=(localdb)\\MSSQLLocalDB;Database=HRMSBackEnd;Trusted_Connection=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AllowanceDeduction>(entity =>
        {
            entity.HasKey(e => e.AdId).HasName("PK__Allowanc__CAA4A6271FAF443E");

            entity.ToTable("AllowanceDeduction");

            entity.HasIndex(e => e.Currency, "IX_AllowanceDeduction_Currency");

            entity.HasIndex(e => e.EmployeeId, "IX_AllowanceDeduction_EmployeeID");

            entity.HasIndex(e => e.PayrollId, "IX_AllowanceDeduction_PayrollID");

            entity.HasIndex(e => e.Type, "IX_AllowanceDeduction_Type");

            entity.Property(e => e.AdId).HasColumnName("ad_id");
            entity.Property(e => e.Amount)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("amount");
            entity.Property(e => e.Currency)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("currency");
            entity.Property(e => e.Duration)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("duration");
            entity.Property(e => e.EmployeeId).HasColumnName("employee_id");
            entity.Property(e => e.PayrollId).HasColumnName("payroll_id");
            entity.Property(e => e.Timezone)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("timezone");
            entity.Property(e => e.Type)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("type");

            entity.HasOne(d => d.CurrencyNavigation).WithMany(p => p.AllowanceDeductions)
                .HasForeignKey(d => d.Currency)
                .HasConstraintName("FK__Allowance__curre__793DFFAF");

            entity.HasOne(d => d.Employee).WithMany(p => p.AllowanceDeductions)
                .HasForeignKey(d => d.EmployeeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Allowance__emplo__7849DB76");

            entity.HasOne(d => d.Payroll).WithMany(p => p.AllowanceDeductions)
                .HasForeignKey(d => d.PayrollId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Allowance__payro__7755B73D");
        });

        modelBuilder.Entity<ApprovalWorkflow>(entity =>
        {
            entity.HasKey(e => e.WorkflowId).HasName("PK__Approval__64A76B70DAB84DC3");

            entity.ToTable("ApprovalWorkflow");

            entity.Property(e => e.WorkflowId).HasColumnName("workflow_id");
            entity.Property(e => e.ApproverRole)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("approver_role");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.Status)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasDefaultValue("Active")
                .HasColumnName("status");
            entity.Property(e => e.ThresholdAmount)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("threshold_amount");
            entity.Property(e => e.WorkflowType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("workflow_type");

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.ApprovalWorkflows)
                .HasForeignKey(d => d.CreatedBy)
                .HasConstraintName("FK__ApprovalW__creat__6FB49575");
        });

        modelBuilder.Entity<ApprovalWorkflowStep>(entity =>
        {
            entity.HasKey(e => new { e.WorkflowId, e.StepNumber }).HasName("PK__Approval__D7E8C76589CB3D76");

            entity.ToTable("ApprovalWorkflowStep");

            entity.HasIndex(e => e.RoleId, "IX_ApprovalWorkflowStep_Role");

            entity.HasIndex(e => e.WorkflowId, "IX_ApprovalWorkflowStep_Workflow");

            entity.Property(e => e.WorkflowId).HasColumnName("workflow_id");
            entity.Property(e => e.StepNumber).HasColumnName("step_number");
            entity.Property(e => e.ActionRequired)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("action_required");
            entity.Property(e => e.RoleId).HasColumnName("role_id");

            entity.HasOne(d => d.Role).WithMany(p => p.ApprovalWorkflowSteps)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ApprovalW__role___719CDDE7");

            entity.HasOne(d => d.Workflow).WithMany(p => p.ApprovalWorkflowSteps)
                .HasForeignKey(d => d.WorkflowId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ApprovalW__workf__70A8B9AE");
        });

        modelBuilder.Entity<Attendance>(entity =>
        {
            entity.HasKey(e => e.AttendanceId).HasName("PK__Attendan__20D6A968691C521C");

            entity.ToTable("Attendance");

            entity.HasIndex(e => e.EmployeeId, "IX_Attendance_EmployeeID");

            entity.HasIndex(e => e.EntryTime, "IX_Attendance_EntryTime");

            entity.HasIndex(e => e.ExceptionId, "IX_Attendance_ExceptionID");

            entity.HasIndex(e => e.ExitTime, "IX_Attendance_ExitTime");

            entity.HasIndex(e => e.ShiftId, "IX_Attendance_ShiftID");

            entity.Property(e => e.AttendanceId).HasColumnName("attendance_id");
            entity.Property(e => e.Duration).HasColumnName("duration");
            entity.Property(e => e.EmployeeId).HasColumnName("employee_id");
            entity.Property(e => e.EntryTime)
                .HasColumnType("datetime")
                .HasColumnName("entry_time");
            entity.Property(e => e.ExceptionId).HasColumnName("exception_id");
            entity.Property(e => e.ExitTime)
                .HasColumnType("datetime")
                .HasColumnName("exit_time");
            entity.Property(e => e.LoginMethod)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("login_method");
            entity.Property(e => e.LogoutMethod)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("logout_method");
            entity.Property(e => e.ShiftId).HasColumnName("shift_id");

            entity.HasOne(d => d.Employee).WithMany(p => p.Attendances)
                .HasForeignKey(d => d.EmployeeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Attendanc__emplo__1C873BEC");

            entity.HasOne(d => d.Exception).WithMany(p => p.Attendances)
                .HasForeignKey(d => d.ExceptionId)
                .HasConstraintName("FK__Attendanc__excep__1E6F845E");

            entity.HasOne(d => d.Shift).WithMany(p => p.Attendances)
                .HasForeignKey(d => d.ShiftId)
                .HasConstraintName("FK__Attendanc__shift__1D7B6025");
        });

        modelBuilder.Entity<AttendanceCorrectionRequest>(entity =>
        {
            entity.HasKey(e => e.RequestId).HasName("PK__Attendan__18D3B90F9AC913C8");

            entity.ToTable("AttendanceCorrectionRequest");

            entity.HasIndex(e => e.Date, "IX_AttendanceCorrectionRequest_Date");

            entity.HasIndex(e => e.EmployeeId, "IX_AttendanceCorrectionRequest_EmployeeID");

            entity.HasIndex(e => e.Status, "IX_AttendanceCorrectionRequest_Status");

            entity.Property(e => e.RequestId).HasColumnName("request_id");
            entity.Property(e => e.CorrectionType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("correction_type");
            entity.Property(e => e.Date).HasColumnName("date");
            entity.Property(e => e.EmployeeId).HasColumnName("employee_id");
            entity.Property(e => e.Reason)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("reason");
            entity.Property(e => e.RecordedBy).HasColumnName("recorded_by");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasDefaultValue("Pending")
                .HasColumnName("status");

            entity.HasOne(d => d.Employee).WithMany(p => p.AttendanceCorrectionRequestEmployees)
                .HasForeignKey(d => d.EmployeeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Attendanc__emplo__22401542");

            entity.HasOne(d => d.RecordedByNavigation).WithMany(p => p.AttendanceCorrectionRequestRecordedByNavigations)
                .HasForeignKey(d => d.RecordedBy)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Attendanc__recor__2334397B");
        });

        modelBuilder.Entity<AttendanceLog>(entity =>
        {
            entity.HasKey(e => e.AttendanceLogId).HasName("PK__Attendan__DB38FB09C751AA13");

            entity.ToTable("AttendanceLog");

            entity.HasIndex(e => e.Actor, "IX_AttendanceLog_Actor");

            entity.HasIndex(e => e.AttendanceId, "IX_AttendanceLog_AttendanceID");

            entity.HasIndex(e => e.Timestamp, "IX_AttendanceLog_Timestamp");

            entity.Property(e => e.AttendanceLogId).HasColumnName("attendance_log_id");
            entity.Property(e => e.Actor).HasColumnName("actor");
            entity.Property(e => e.AttendanceId).HasColumnName("attendance_id");
            entity.Property(e => e.Reason)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("reason");
            entity.Property(e => e.Timestamp)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("timestamp");

            entity.HasOne(d => d.Attendance).WithMany(p => p.AttendanceLogs)
                .HasForeignKey(d => d.AttendanceId)
                .HasConstraintName("FK__Attendanc__atten__214BF109");
        });

        modelBuilder.Entity<AttendanceSource>(entity =>
        {
            entity.HasKey(e => new { e.AttendanceId, e.DeviceId }).HasName("PK__Attendan__83662CB08198009B");

            entity.ToTable("AttendanceSource");

            entity.HasIndex(e => e.AttendanceId, "IX_AttendanceSource_AttendanceID");

            entity.HasIndex(e => e.DeviceId, "IX_AttendanceSource_DeviceID");

            entity.Property(e => e.AttendanceId).HasColumnName("attendance_id");
            entity.Property(e => e.DeviceId).HasColumnName("device_id");
            entity.Property(e => e.Latitude)
                .HasColumnType("decimal(10, 7)")
                .HasColumnName("latitude");
            entity.Property(e => e.Longitude)
                .HasColumnType("decimal(10, 7)")
                .HasColumnName("longitude");
            entity.Property(e => e.RecordedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("recorded_at");
            entity.Property(e => e.SourceType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("source_type");

            entity.HasOne(d => d.Attendance).WithMany(p => p.AttendanceSources)
                .HasForeignKey(d => d.AttendanceId)
                .HasConstraintName("FK__Attendanc__atten__251C81ED");

            entity.HasOne(d => d.Device).WithMany(p => p.AttendanceSources)
                .HasForeignKey(d => d.DeviceId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Attendanc__devic__2610A626");
        });

        modelBuilder.Entity<BonusPolicy>(entity =>
        {
            entity.HasKey(e => e.PolicyId).HasName("PK__BonusPol__47DA3F034521B447");

            entity.ToTable("BonusPolicy");

            entity.Property(e => e.PolicyId)
                .ValueGeneratedNever()
                .HasColumnName("policy_id");
            entity.Property(e => e.BonusType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("bonus_type");
            entity.Property(e => e.EligibilityCriteria).HasColumnName("eligibility_criteria");

            entity.HasOne(d => d.Policy).WithOne(p => p.BonusPolicy)
                .HasForeignKey<BonusPolicy>(d => d.PolicyId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__BonusPoli__polic__7C1A6C5A");
        });

        modelBuilder.Entity<ConsultantContract>(entity =>
        {
            entity.HasKey(e => e.ContractId).HasName("PK__Consulta__F8D6642345D48ABB");

            entity.ToTable("ConsultantContract");

            entity.Property(e => e.ContractId)
                .ValueGeneratedNever()
                .HasColumnName("contract_id");
            entity.Property(e => e.Fees)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("fees");
            entity.Property(e => e.PaymentSchedule)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("payment_schedule");
            entity.Property(e => e.ProjectScope)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("project_scope");

            entity.HasOne(d => d.Contract).WithOne(p => p.ConsultantContract)
                .HasForeignKey<ConsultantContract>(d => d.ContractId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Consultan__contr__0A688BB1");
        });

        modelBuilder.Entity<Contract>(entity =>
        {
            entity.HasKey(e => e.ContractId).HasName("PK__Contract__F8D664232335CC20");

            entity.ToTable("Contract");

            entity.HasIndex(e => e.EndDate, "IX_Contract_EndDate");

            entity.HasIndex(e => e.StartDate, "IX_Contract_StartDate");

            entity.HasIndex(e => e.CurrentState, "IX_Contract_State");

            entity.HasIndex(e => e.Type, "IX_Contract_Type");

            entity.Property(e => e.ContractId).HasColumnName("contract_id");
            entity.Property(e => e.CurrentState)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("current_state");
            entity.Property(e => e.EndDate).HasColumnName("end_date");
            entity.Property(e => e.StartDate).HasColumnName("start_date");
            entity.Property(e => e.Type)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("type");
        });

        modelBuilder.Entity<ContractSalaryType>(entity =>
        {
            entity.HasKey(e => e.SalaryTypeId).HasName("PK__Contract__4D6470623CF9FA4D");

            entity.ToTable("ContractSalaryType");

            entity.Property(e => e.SalaryTypeId)
                .ValueGeneratedNever()
                .HasColumnName("salary_type_id");
            entity.Property(e => e.ContractValue)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("contract_value");
            entity.Property(e => e.InstallmentDetails)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("installment_details");

            entity.HasOne(d => d.SalaryType).WithOne(p => p.ContractSalaryType)
                .HasForeignKey<ContractSalaryType>(d => d.SalaryTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ContractS__salar__756D6ECB");
        });

        modelBuilder.Entity<Currency>(entity =>
        {
            entity.HasKey(e => e.CurrencyCode).HasName("PK__Currency__408426BEAC81A423");

            entity.ToTable("Currency");

            entity.HasIndex(e => e.LastUpdated, "IX_Currency_LastUpdated");

            entity.HasIndex(e => e.CurrencyName, "IX_Currency_Name");

            entity.Property(e => e.CurrencyCode)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.CurrencyName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.ExchangeRate).HasColumnType("decimal(10, 4)");
            entity.Property(e => e.LastUpdated)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
        });

        modelBuilder.Entity<DeductionPolicy>(entity =>
        {
            entity.HasKey(e => e.PolicyId).HasName("PK__Deductio__47DA3F03F1A37E12");

            entity.ToTable("DeductionPolicy");

            entity.Property(e => e.PolicyId)
                .ValueGeneratedNever()
                .HasColumnName("policy_id");
            entity.Property(e => e.CalculationMode)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("calculation_mode");
            entity.Property(e => e.DeductionReason)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("deduction_reason");

            entity.HasOne(d => d.Policy).WithOne(p => p.DeductionPolicy)
                .HasForeignKey<DeductionPolicy>(d => d.PolicyId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Deduction__polic__7D0E9093");
        });

        modelBuilder.Entity<Department>(entity =>
        {
            entity.HasKey(e => e.DepartmentId).HasName("PK__Departme__C22324229464D75D");

            entity.ToTable("Department");

            entity.HasIndex(e => e.DepartmentHeadId, "IX_Department_Head");

            entity.HasIndex(e => e.DepartmentName, "IX_Department_Name");

            entity.HasIndex(e => e.DepartmentName, "UQ__Departme__226ED157188F9E18").IsUnique();

            entity.Property(e => e.DepartmentId).HasColumnName("department_id");
            entity.Property(e => e.DepartmentHeadId).HasColumnName("department_head_id");
            entity.Property(e => e.DepartmentName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("department_name");
            entity.Property(e => e.Purpose)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("purpose");

            entity.HasOne(d => d.DepartmentHead).WithMany(p => p.Departments)
                .HasForeignKey(d => d.DepartmentHeadId)
                .HasConstraintName("FK_Department_Head");
        });

        modelBuilder.Entity<Device>(entity =>
        {
            entity.HasKey(e => e.DeviceId).HasName("PK__Device__3B085D8BF782AC0A");

            entity.ToTable("Device");

            entity.HasIndex(e => e.EmployeeId, "IX_Device_EmployeeID");

            entity.HasIndex(e => e.DeviceType, "IX_Device_Type");

            entity.HasIndex(e => e.TerminalId, "UQ__Device__A7A7EB4078E3397F").IsUnique();

            entity.Property(e => e.DeviceId).HasColumnName("device_id");
            entity.Property(e => e.DeviceType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("device_type");
            entity.Property(e => e.EmployeeId).HasColumnName("employee_id");
            entity.Property(e => e.Latitude)
                .HasColumnType("decimal(10, 7)")
                .HasColumnName("latitude");
            entity.Property(e => e.Longitude)
                .HasColumnType("decimal(10, 7)")
                .HasColumnName("longitude");
            entity.Property(e => e.TerminalId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("terminal_id");

            entity.HasOne(d => d.Employee).WithMany(p => p.Devices)
                .HasForeignKey(d => d.EmployeeId)
                .HasConstraintName("FK__Device__employee__24285DB4");
        });

        modelBuilder.Entity<Employee>(entity =>
        {
            entity.HasKey(e => e.EmployeeId).HasName("PK__Employee__C52E0BA888D9AE5A");

            entity.ToTable("Employee");

            entity.HasIndex(e => e.DepartmentId, "IX_Employee_Department");

            entity.HasIndex(e => e.Email, "IX_Employee_Email");

            entity.HasIndex(e => e.IsActive, "IX_Employee_IsActive");

            entity.HasIndex(e => e.ManagerId, "IX_Employee_Manager");

            entity.HasIndex(e => e.PositionId, "IX_Employee_Position");

            entity.HasIndex(e => e.Email, "UQ__Employee__AB6E61640E85A07C").IsUnique();

            entity.Property(e => e.EmployeeId).HasColumnName("employee_id");
            entity.Property(e => e.AccountStatus)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasDefaultValue("Active")
                .HasColumnName("account_status");
            entity.Property(e => e.Address)
                .HasMaxLength(150)
                .IsUnicode(false)
                .HasColumnName("address");
            entity.Property(e => e.Biography)
                .IsUnicode(false)
                .HasColumnName("biography");
            entity.Property(e => e.ContractId).HasColumnName("contract_id");
            entity.Property(e => e.CountryOfBirth)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("country_of_birth");
            entity.Property(e => e.DateOfBirth).HasColumnName("date_of_birth");
            entity.Property(e => e.DepartmentId).HasColumnName("department_id");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("email");
            entity.Property(e => e.EmergencyContactName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("emergency_contact_name");
            entity.Property(e => e.EmergencyContactPhone)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("emergency_contact_phone");
            entity.Property(e => e.EmploymentProgress)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("employment_progress");
            entity.Property(e => e.EmploymentStatus)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasDefaultValue("Active")
                .HasColumnName("employment_status");
            entity.Property(e => e.FirstName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("first_name");
            entity.Property(e => e.FullName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("full_name");
            entity.Property(e => e.HireDate).HasColumnName("hire_date");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.LastName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("last_name");
            entity.Property(e => e.ManagerId).HasColumnName("manager_id");
            entity.Property(e => e.NationalId)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("national_id");
            entity.Property(e => e.PayGrade).HasColumnName("pay_grade");
            entity.Property(e => e.Phone)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("phone");
            entity.Property(e => e.PositionId).HasColumnName("position_id");
            entity.Property(e => e.ProfileCompletion)
                .HasDefaultValue(0)
                .HasColumnName("profile_completion");
            entity.Property(e => e.ProfileImage)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("profile_image");
            entity.Property(e => e.Relationship)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("relationship");
            entity.Property(e => e.SalaryTypeId).HasColumnName("salary_type_id");
            entity.Property(e => e.TaxFormId).HasColumnName("tax_form_id");

            entity.HasOne(d => d.Contract).WithMany(p => p.Employees)
                .HasForeignKey(d => d.ContractId)
                .HasConstraintName("FK__Employee__contra__6442E2C9");

            entity.HasOne(d => d.Department).WithMany(p => p.Employees)
                .HasForeignKey(d => d.DepartmentId)
                .HasConstraintName("FK__Employee__depart__6166761E");

            entity.HasOne(d => d.Manager).WithMany(p => p.InverseManager)
                .HasForeignKey(d => d.ManagerId)
                .HasConstraintName("FK__Employee__manage__625A9A57");

            entity.HasOne(d => d.PayGradeNavigation).WithMany(p => p.Employees)
                .HasForeignKey(d => d.PayGrade)
                .HasConstraintName("FK__Employee__pay_gr__5F7E2DAC");

            entity.HasOne(d => d.Position).WithMany(p => p.Employees)
                .HasForeignKey(d => d.PositionId)
                .HasConstraintName("FK__Employee__positi__5E8A0973");

            entity.HasOne(d => d.SalaryType).WithMany(p => p.Employees)
                .HasForeignKey(d => d.SalaryTypeId)
                .HasConstraintName("FK__Employee__salary__634EBE90");

            entity.HasOne(d => d.TaxForm).WithMany(p => p.Employees)
                .HasForeignKey(d => d.TaxFormId)
                .HasConstraintName("FK__Employee__tax_fo__607251E5");

            entity.HasMany(d => d.Exceptions).WithMany(p => p.Employees)
                .UsingEntity<Dictionary<string, object>>(
                    "EmployeeException",
                    r => r.HasOne<Exception>().WithMany()
                        .HasForeignKey("ExceptionId")
                        .HasConstraintName("FK__Employee___excep__2057CCD0"),
                    l => l.HasOne<Employee>().WithMany()
                        .HasForeignKey("EmployeeId")
                        .HasConstraintName("FK__Employee___emplo__1F63A897"),
                    j =>
                    {
                        j.HasKey("EmployeeId", "ExceptionId").HasName("PK__Employee__F96CD56451E64846");
                        j.ToTable("Employee_Exception");
                        j.IndexerProperty<int>("EmployeeId").HasColumnName("employee_id");
                        j.IndexerProperty<int>("ExceptionId").HasColumnName("exception_id");
                    });

            entity.HasMany(d => d.Verifications).WithMany(p => p.Employees)
                .UsingEntity<Dictionary<string, object>>(
                    "EmployeeVerification",
                    r => r.HasOne<Verification>().WithMany()
                        .HasForeignKey("VerificationId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK_EmployeeVerification_Verification"),
                    l => l.HasOne<Employee>().WithMany()
                        .HasForeignKey("EmployeeId")
                        .HasConstraintName("FK_EmployeeVerification_Employee"),
                    j =>
                    {
                        j.HasKey("EmployeeId", "VerificationId").HasName("PK__Employee__47611C3EC21F5B32");
                        j.ToTable("Employee_Verification");
                        j.HasIndex(new[] { "EmployeeId" }, "IX_EmployeeVerification_Employee");
                        j.HasIndex(new[] { "VerificationId" }, "IX_EmployeeVerification_Verification");
                        j.IndexerProperty<int>("EmployeeId").HasColumnName("employee_id");
                        j.IndexerProperty<int>("VerificationId").HasColumnName("verification_id");
                    });
        });

        modelBuilder.Entity<EmployeeHierarchy>(entity =>
        {
            entity.HasKey(e => new { e.EmployeeId, e.ManagerId }).HasName("PK__Employee__10880C97F1A7747F");

            entity.ToTable("EmployeeHierarchy");

            entity.HasIndex(e => e.EmployeeId, "IX_EmployeeHierarchy_Employee");

            entity.HasIndex(e => e.ManagerId, "IX_EmployeeHierarchy_Manager");

            entity.Property(e => e.EmployeeId).HasColumnName("employee_id");
            entity.Property(e => e.ManagerId).HasColumnName("manager_id");
            entity.Property(e => e.HierarchyLevel)
                .HasDefaultValue(1)
                .HasColumnName("hierarchy_level");

            entity.HasOne(d => d.Employee).WithMany(p => p.EmployeeHierarchyEmployees)
                .HasForeignKey(d => d.EmployeeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__EmployeeH__emplo__6BE40491");

            entity.HasOne(d => d.Manager).WithMany(p => p.EmployeeHierarchyManagers)
                .HasForeignKey(d => d.ManagerId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__EmployeeH__manag__6CD828CA");
        });

        modelBuilder.Entity<EmployeeNotification>(entity =>
        {
            entity.HasKey(e => new { e.EmployeeId, e.NotificationId }).HasName("PK__Employee__2B2B93EAD9F47C73");

            entity.ToTable("Employee_Notification");

            entity.HasIndex(e => e.DeliveryStatus, "IX_EmployeeNotification_DeliveryStatus");

            entity.HasIndex(e => e.EmployeeId, "IX_EmployeeNotification_Employee");

            entity.HasIndex(e => e.NotificationId, "IX_EmployeeNotification_Notification");

            entity.Property(e => e.EmployeeId).HasColumnName("employee_id");
            entity.Property(e => e.NotificationId).HasColumnName("notification_id");
            entity.Property(e => e.DeliveredAt)
                .HasColumnType("datetime")
                .HasColumnName("delivered_at");
            entity.Property(e => e.DeliveryStatus)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasDefaultValue("Pending")
                .HasColumnName("delivery_status");

            entity.HasOne(d => d.Employee).WithMany(p => p.EmployeeNotifications)
                .HasForeignKey(d => d.EmployeeId)
                .HasConstraintName("FK_EmployeeNotification_Employee");

            entity.HasOne(d => d.Notification).WithMany(p => p.EmployeeNotifications)
                .HasForeignKey(d => d.NotificationId)
                .HasConstraintName("FK_EmployeeNotification_Notification");
        });

        modelBuilder.Entity<EmployeeRole>(entity =>
        {
            entity.HasKey(e => new { e.EmployeeId, e.RoleId }).HasName("PK__Employee__124E9DF4CEE8B43A");

            entity.ToTable("Employee_Role");

            entity.HasIndex(e => e.EmployeeId, "IX_EmployeeRole_Employee");

            entity.HasIndex(e => e.RoleId, "IX_EmployeeRole_Role");

            entity.Property(e => e.EmployeeId).HasColumnName("employee_id");
            entity.Property(e => e.RoleId).HasColumnName("role_id");
            entity.Property(e => e.AssignedDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("assigned_date");

            entity.HasOne(d => d.Employee).WithMany(p => p.EmployeeRoles)
                .HasForeignKey(d => d.EmployeeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Employee___emplo__69FBBC1F");

            entity.HasOne(d => d.Role).WithMany(p => p.EmployeeRoles)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Employee___role___6AEFE058");
        });

        modelBuilder.Entity<EmployeeSkill>(entity =>
        {
            entity.HasKey(e => new { e.EmployeeId, e.SkillId }).HasName("PK__Employee__4A95A39FC49E88E1");

            entity.ToTable("Employee_Skill");

            entity.HasIndex(e => e.EmployeeId, "IX_EmployeeSkill_Employee");

            entity.HasIndex(e => e.ProficiencyLevel, "IX_EmployeeSkill_Proficiency");

            entity.HasIndex(e => e.SkillId, "IX_EmployeeSkill_Skill");

            entity.Property(e => e.EmployeeId).HasColumnName("employee_id");
            entity.Property(e => e.SkillId).HasColumnName("skill_id");
            entity.Property(e => e.ProficiencyLevel)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("proficiency_level");

            entity.HasOne(d => d.Employee).WithMany(p => p.EmployeeSkills)
                .HasForeignKey(d => d.EmployeeId)
                .HasConstraintName("FK_EmployeeSkill_Employee");

            entity.HasOne(d => d.Skill).WithMany(p => p.EmployeeSkills)
                .HasForeignKey(d => d.SkillId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_EmployeeSkill_Skill");
        });

        modelBuilder.Entity<Exception>(entity =>
        {
            entity.HasKey(e => e.ExceptionId).HasName("PK__Exceptio__C42DECC24A2648A9");

            entity.ToTable("Exception");

            entity.HasIndex(e => e.Category, "IX_Exception_Category");

            entity.HasIndex(e => e.Date, "IX_Exception_Date");

            entity.HasIndex(e => e.Status, "IX_Exception_Status");

            entity.Property(e => e.ExceptionId).HasColumnName("exception_id");
            entity.Property(e => e.Category)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("category");
            entity.Property(e => e.Date).HasColumnName("date");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("name");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("status");
        });

        modelBuilder.Entity<FullTimeContract>(entity =>
        {
            entity.HasKey(e => e.ContractId).HasName("PK__FullTime__F8D66423884C6CEF");

            entity.ToTable("FullTimeContract");

            entity.HasIndex(e => e.InsuranceEligibility, "IX_FullTimeContract_Eligibility");

            entity.Property(e => e.ContractId)
                .ValueGeneratedNever()
                .HasColumnName("contract_id");
            entity.Property(e => e.InsuranceEligibility).HasColumnName("insurance_eligibility");
            entity.Property(e => e.LeaveEntitlement).HasColumnName("leave_entitlement");
            entity.Property(e => e.WeeklyWorkingHours).HasColumnName("weekly_working_hours");

            entity.HasOne(d => d.Contract).WithOne(p => p.FullTimeContract)
                .HasForeignKey<FullTimeContract>(d => d.ContractId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__FullTimeC__contr__0880433F");
        });

        modelBuilder.Entity<HolidayLeave>(entity =>
        {
            entity.HasKey(e => e.LeaveId).HasName("PK__HolidayL__743350BC6A14013C");

            entity.ToTable("HolidayLeave");

            entity.Property(e => e.LeaveId)
                .ValueGeneratedNever()
                .HasColumnName("leave_id");
            entity.Property(e => e.HolidayName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("holiday_name");
            entity.Property(e => e.OfficialRecognition)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("official_recognition");
            entity.Property(e => e.RegionalScope)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("regional_scope");

            entity.HasOne(d => d.Leave).WithOne(p => p.HolidayLeave)
                .HasForeignKey<HolidayLeave>(d => d.LeaveId)
                .HasConstraintName("FK__HolidayLe__leave__12FDD1B2");
        });

        modelBuilder.Entity<HourlySalaryType>(entity =>
        {
            entity.HasKey(e => e.SalaryTypeId).HasName("PK__HourlySa__4D6470628DC63896");

            entity.ToTable("HourlySalaryType");

            entity.Property(e => e.SalaryTypeId)
                .ValueGeneratedNever()
                .HasColumnName("salary_type_id");
            entity.Property(e => e.HourlyRate)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("hourly_rate");
            entity.Property(e => e.MaxMonthlyHours).HasColumnName("max_monthly_hours");

            entity.HasOne(d => d.SalaryType).WithOne(p => p.HourlySalaryType)
                .HasForeignKey<HourlySalaryType>(d => d.SalaryTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__HourlySal__salar__73852659");
        });

        modelBuilder.Entity<Hradministrator>(entity =>
        {
            entity.HasKey(e => e.EmployeeId).HasName("PK__HRAdmini__C52E0BA85B41AC0F");

            entity.ToTable("HRAdministrator");

            entity.Property(e => e.EmployeeId)
                .ValueGeneratedNever()
                .HasColumnName("employee_id");
            entity.Property(e => e.ApprovalLevel)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasDefaultValue("Junior")
                .HasColumnName("approval_level");
            entity.Property(e => e.DocumentValidationRights)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("document_validation_rights");
            entity.Property(e => e.RecordAccessScope)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("record_access_scope");

            entity.HasOne(d => d.Employee).WithOne(p => p.Hradministrator)
                .HasForeignKey<Hradministrator>(d => d.EmployeeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__HRAdminis__emplo__65370702");
        });

        modelBuilder.Entity<Insurance>(entity =>
        {
            entity.HasKey(e => e.InsuranceId).HasName("PK__Insuranc__58B60F4558BBA42B");

            entity.ToTable("Insurance");

            entity.HasIndex(e => e.Type, "IX_Insurance_Type");

            entity.Property(e => e.InsuranceId).HasColumnName("insurance_id");
            entity.Property(e => e.ContributionRate)
                .HasColumnType("decimal(5, 2)")
                .HasColumnName("contribution_rate");
            entity.Property(e => e.Coverage)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("coverage");
            entity.Property(e => e.Type)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("type");
        });

        modelBuilder.Entity<InternshipContract>(entity =>
        {
            entity.HasKey(e => e.ContractId).HasName("PK__Internsh__F8D66423C27DD538");

            entity.ToTable("InternshipContract");

            entity.Property(e => e.ContractId)
                .ValueGeneratedNever()
                .HasColumnName("contract_id");
            entity.Property(e => e.Evaluation)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("evaluation");
            entity.Property(e => e.Mentoring)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("mentoring");
            entity.Property(e => e.StipendRelated)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("stipend_related");

            entity.HasOne(d => d.Contract).WithOne(p => p.InternshipContract)
                .HasForeignKey<InternshipContract>(d => d.ContractId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Internshi__contr__0B5CAFEA");
        });

        modelBuilder.Entity<LatenessPolicy>(entity =>
        {
            entity.HasKey(e => e.PolicyId).HasName("PK__Lateness__47DA3F0353373D5D");

            entity.ToTable("LatenessPolicy");

            entity.Property(e => e.PolicyId)
                .ValueGeneratedNever()
                .HasColumnName("policy_id");
            entity.Property(e => e.DeductionRate)
                .HasColumnType("decimal(5, 2)")
                .HasColumnName("deduction_rate");
            entity.Property(e => e.GracePeriodMins).HasColumnName("grace_period_mins");

            entity.HasOne(d => d.Policy).WithOne(p => p.LatenessPolicy)
                .HasForeignKey<LatenessPolicy>(d => d.PolicyId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__LatenessP__polic__7B264821");
        });

        modelBuilder.Entity<Leave>(entity =>
        {
            entity.HasKey(e => e.LeaveId).HasName("PK__Leave__743350BCCF64DA15");

            entity.ToTable("Leave");

            entity.HasIndex(e => e.LeaveType, "IX_Leave_Type");

            entity.Property(e => e.LeaveId).HasColumnName("leave_id");
            entity.Property(e => e.LeaveDescription)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("leave_description");
            entity.Property(e => e.LeaveType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("leave_type");
        });

        modelBuilder.Entity<LeaveDocument>(entity =>
        {
            entity.HasKey(e => e.DocumentId).HasName("PK__LeaveDoc__9666E8ACB8178FEC");

            entity.ToTable("LeaveDocument");

            entity.HasIndex(e => e.LeaveRequestId, "IX_LeaveDocument_RequestID");

            entity.Property(e => e.DocumentId).HasColumnName("document_id");
            entity.Property(e => e.FilePath)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("file_path");
            entity.Property(e => e.LeaveRequestId).HasColumnName("leave_request_id");
            entity.Property(e => e.UploadedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("uploaded_at");

            entity.HasOne(d => d.LeaveRequest).WithMany(p => p.LeaveDocuments)
                .HasForeignKey(d => d.LeaveRequestId)
                .HasConstraintName("FK__LeaveDocu__leave__17C286CF");
        });

        modelBuilder.Entity<LeaveEntitlement>(entity =>
        {
            entity.HasKey(e => new { e.EmployeeId, e.LeaveTypeId }).HasName("PK__LeaveEnt__92097AE5C277D058");

            entity.ToTable("LeaveEntitlement");

            entity.HasIndex(e => e.EmployeeId, "IX_LeaveEntitlement_EmployeeID");

            entity.HasIndex(e => e.LeaveTypeId, "IX_LeaveEntitlement_LeaveTypeID");

            entity.Property(e => e.EmployeeId).HasColumnName("employee_id");
            entity.Property(e => e.LeaveTypeId).HasColumnName("leave_type_id");
            entity.Property(e => e.Entitlement)
                .HasColumnType("decimal(5, 2)")
                .HasColumnName("entitlement");

            entity.HasOne(d => d.Employee).WithMany(p => p.LeaveEntitlements)
                .HasForeignKey(d => d.EmployeeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__LeaveEnti__emplo__15DA3E5D");

            entity.HasOne(d => d.LeaveType).WithMany(p => p.LeaveEntitlements)
                .HasForeignKey(d => d.LeaveTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__LeaveEnti__leave__16CE6296");
        });

        modelBuilder.Entity<LeavePolicy>(entity =>
        {
            entity.HasKey(e => e.PolicyId).HasName("PK__LeavePol__47DA3F0348EBF808");

            entity.ToTable("LeavePolicy");

            entity.Property(e => e.PolicyId).HasColumnName("policy_id");
            entity.Property(e => e.EligibilityRules)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("eligibility_rules");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("name");
            entity.Property(e => e.NoticePeriod).HasColumnName("notice_period");
            entity.Property(e => e.Purpose)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("purpose");
            entity.Property(e => e.ResetOnNewYear)
                .HasDefaultValue(true)
                .HasColumnName("reset_on_new_year");
            entity.Property(e => e.SpecialLeaveType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("special_leave_type");
        });

        modelBuilder.Entity<LeaveRequest>(entity =>
        {
            entity.HasKey(e => e.RequestId).HasName("PK__LeaveReq__18D3B90FAEC1525C");

            entity.ToTable("LeaveRequest");

            entity.HasIndex(e => e.ApprovalTiming, "IX_LeaveRequest_ApprovalTiming");

            entity.HasIndex(e => e.EmployeeId, "IX_LeaveRequest_EmployeeID");

            entity.HasIndex(e => e.LeaveId, "IX_LeaveRequest_LeaveID");

            entity.HasIndex(e => e.Status, "IX_LeaveRequest_Status");

            entity.Property(e => e.RequestId).HasColumnName("request_id");
            entity.Property(e => e.ApprovalTiming)
                .HasColumnType("datetime")
                .HasColumnName("approval_timing");
            entity.Property(e => e.Duration).HasColumnName("duration");
            entity.Property(e => e.EmployeeId).HasColumnName("employee_id");
            entity.Property(e => e.Justification)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("justification");
            entity.Property(e => e.LeaveId).HasColumnName("leave_id");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("status");

            entity.HasOne(d => d.Employee).WithMany(p => p.LeaveRequests)
                .HasForeignKey(d => d.EmployeeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__LeaveRequ__emplo__13F1F5EB");

            entity.HasOne(d => d.Leave).WithMany(p => p.LeaveRequests)
                .HasForeignKey(d => d.LeaveId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__LeaveRequ__leave__14E61A24");
        });

        modelBuilder.Entity<LineManager>(entity =>
        {
            entity.HasKey(e => e.EmployeeId).HasName("PK__LineMana__C52E0BA8FF71F342");

            entity.ToTable("LineManager");

            entity.Property(e => e.EmployeeId)
                .ValueGeneratedNever()
                .HasColumnName("employee_id");
            entity.Property(e => e.ApprovalLimit)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("approval_limit");
            entity.Property(e => e.SupervisedDepartments)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("supervised_departments");
            entity.Property(e => e.TeamSize)
                .HasDefaultValue(0)
                .HasColumnName("team_size");

            entity.HasOne(d => d.Employee).WithOne(p => p.LineManager)
                .HasForeignKey<LineManager>(d => d.EmployeeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__LineManag__emplo__681373AD");
        });

        modelBuilder.Entity<ManagerNote>(entity =>
        {
            entity.HasKey(e => e.NoteId).HasName("PK__ManagerN__CEDD0FA481A915EF");

            entity.HasIndex(e => e.EmployeeId, "IX_ManagerNotes_Employee");

            entity.HasIndex(e => e.ManagerId, "IX_ManagerNotes_Manager");

            entity.Property(e => e.NoteId).HasColumnName("note_id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("created_at");
            entity.Property(e => e.EmployeeId).HasColumnName("employee_id");
            entity.Property(e => e.ManagerId).HasColumnName("manager_id");
            entity.Property(e => e.NoteContent)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("note_content");

            entity.HasOne(d => d.Employee).WithMany(p => p.ManagerNoteEmployees)
                .HasForeignKey(d => d.EmployeeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ManagerNo__emplo__6DCC4D03");

            entity.HasOne(d => d.Manager).WithMany(p => p.ManagerNoteManagers)
                .HasForeignKey(d => d.ManagerId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ManagerNo__manag__6EC0713C");
        });

        modelBuilder.Entity<Mission>(entity =>
        {
            entity.HasKey(e => e.MissionId).HasName("PK__Mission__B5419AB250AD7DB7");

            entity.ToTable("Mission");

            entity.HasIndex(e => e.EmployeeId, "IX_Mission_EmployeeID");

            entity.HasIndex(e => e.EndDate, "IX_Mission_EndDate");

            entity.HasIndex(e => e.ManagerId, "IX_Mission_ManagerID");

            entity.HasIndex(e => e.StartDate, "IX_Mission_StartDate");

            entity.HasIndex(e => e.Status, "IX_Mission_Status");

            entity.Property(e => e.MissionId).HasColumnName("mission_id");
            entity.Property(e => e.Destination)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("destination");
            entity.Property(e => e.EmployeeId).HasColumnName("employee_id");
            entity.Property(e => e.EndDate).HasColumnName("end_date");
            entity.Property(e => e.ManagerId).HasColumnName("manager_id");
            entity.Property(e => e.StartDate).HasColumnName("start_date");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("status");

            entity.HasOne(d => d.Employee).WithMany(p => p.MissionEmployees)
                .HasForeignKey(d => d.EmployeeId)
                .HasConstraintName("FK__Mission__employe__0E391C95");

            entity.HasOne(d => d.Manager).WithMany(p => p.MissionManagers)
                .HasForeignKey(d => d.ManagerId)
                .HasConstraintName("FK__Mission__manager__0F2D40CE");
        });

        modelBuilder.Entity<MonthlySalaryType>(entity =>
        {
            entity.HasKey(e => e.SalaryTypeId).HasName("PK__MonthlyS__4D647062DC890A0C");

            entity.ToTable("MonthlySalaryType");

            entity.Property(e => e.SalaryTypeId)
                .ValueGeneratedNever()
                .HasColumnName("salary_type_id");
            entity.Property(e => e.ContributionScheme)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("contribution_scheme");
            entity.Property(e => e.TaxRule)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("tax_rule");

            entity.HasOne(d => d.SalaryType).WithOne(p => p.MonthlySalaryType)
                .HasForeignKey<MonthlySalaryType>(d => d.SalaryTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__MonthlySa__salar__74794A92");
        });

        modelBuilder.Entity<Notification>(entity =>
        {
            entity.HasKey(e => e.NotificationId).HasName("PK__Notifica__E059842F66D10FA3");

            entity.ToTable("Notification");

            entity.HasIndex(e => e.ReadStatus, "IX_Notification_ReadStatus");

            entity.HasIndex(e => e.Timestamp, "IX_Notification_Timestamp");

            entity.HasIndex(e => e.NotificationType, "IX_Notification_Type");

            entity.HasIndex(e => e.Urgency, "IX_Notification_Urgency");

            entity.Property(e => e.NotificationId).HasColumnName("notification_id");
            entity.Property(e => e.MessageContent)
                .HasMaxLength(1000)
                .IsUnicode(false)
                .HasColumnName("message_content");
            entity.Property(e => e.NotificationType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("notification_type");
            entity.Property(e => e.ReadStatus)
                .HasDefaultValue(false)
                .HasColumnName("read_status");
            entity.Property(e => e.Timestamp)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("timestamp");
            entity.Property(e => e.Urgency)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasDefaultValue("Medium")
                .HasColumnName("urgency");
        });

        modelBuilder.Entity<OvertimePolicy>(entity =>
        {
            entity.HasKey(e => e.PolicyId).HasName("PK__Overtime__47DA3F03A8254694");

            entity.ToTable("OvertimePolicy");

            entity.Property(e => e.PolicyId)
                .ValueGeneratedNever()
                .HasColumnName("policy_id");
            entity.Property(e => e.MaxHoursPerMonth).HasColumnName("max_hours_per_month");
            entity.Property(e => e.WeekdayRateMultiplier)
                .HasColumnType("decimal(3, 2)")
                .HasColumnName("weekday_rate_multiplier");
            entity.Property(e => e.WeekendRateMultiplier)
                .HasColumnType("decimal(3, 2)")
                .HasColumnName("weekend_rate_multiplier");

            entity.HasOne(d => d.Policy).WithOne(p => p.OvertimePolicy)
                .HasForeignKey<OvertimePolicy>(d => d.PolicyId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__OvertimeP__polic__7A3223E8");
        });

        modelBuilder.Entity<PartTimeContract>(entity =>
        {
            entity.HasKey(e => e.ContractId).HasName("PK__PartTime__F8D664232D916E40");

            entity.ToTable("PartTimeContract");

            entity.HasIndex(e => e.HourlyRate, "IX_PartTimeContract_Rate");

            entity.Property(e => e.ContractId)
                .ValueGeneratedNever()
                .HasColumnName("contract_id");
            entity.Property(e => e.HourlyRate)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("hourly_rate");
            entity.Property(e => e.WorkingHours).HasColumnName("working_hours");

            entity.HasOne(d => d.Contract).WithOne(p => p.PartTimeContract)
                .HasForeignKey<PartTimeContract>(d => d.ContractId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__PartTimeC__contr__09746778");
        });

        modelBuilder.Entity<PayGrade>(entity =>
        {
            entity.HasKey(e => e.PayGradeId).HasName("PK__PayGrade__C8AD0DED049A4DA6");

            entity.ToTable("PayGrade");

            entity.HasIndex(e => e.GradeName, "IX_PayGrade_GradeName");

            entity.HasIndex(e => e.GradeName, "UQ__PayGrade__3CA226E130700B9C").IsUnique();

            entity.Property(e => e.PayGradeId).HasColumnName("pay_grade_id");
            entity.Property(e => e.GradeName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("grade_name");
            entity.Property(e => e.MaxSalary)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("max_salary");
            entity.Property(e => e.MinSalary)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("min_salary");
        });

        modelBuilder.Entity<Payroll>(entity =>
        {
            entity.HasKey(e => e.PayrollId).HasName("PK__Payroll__D99FC94414C5ECE0");

            entity.ToTable("Payroll");

            entity.HasIndex(e => e.EmployeeId, "IX_Payroll_EmployeeID");

            entity.HasIndex(e => e.PaymentDate, "IX_Payroll_PaymentDate");

            entity.HasIndex(e => e.PeriodEnd, "IX_Payroll_PeriodEnd");

            entity.HasIndex(e => e.PeriodStart, "IX_Payroll_PeriodStart");

            entity.Property(e => e.PayrollId).HasColumnName("payroll_id");
            entity.Property(e => e.ActualPay)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("actual_pay");
            entity.Property(e => e.Adjustments)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("adjustments");
            entity.Property(e => e.BaseAmount)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("base_amount");
            entity.Property(e => e.Contributions)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("contributions");
            entity.Property(e => e.EmployeeId).HasColumnName("employee_id");
            entity.Property(e => e.NetSalary)
                .HasComputedColumnSql("((([base_amount]+[adjustments])-[taxes])-[contributions])", true)
                .HasColumnType("decimal(13, 2)")
                .HasColumnName("net_salary");
            entity.Property(e => e.PaymentDate).HasColumnName("payment_date");
            entity.Property(e => e.PeriodEnd).HasColumnName("period_end");
            entity.Property(e => e.PeriodStart).HasColumnName("period_start");
            entity.Property(e => e.Taxes)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("taxes");

            entity.HasOne(d => d.Employee).WithMany(p => p.Payrolls)
                .HasForeignKey(d => d.EmployeeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Payroll__employe__76619304");

            entity.HasMany(d => d.Policies).WithMany(p => p.Payrolls)
                .UsingEntity<Dictionary<string, object>>(
                    "PayrollPolicyId",
                    r => r.HasOne<PayrollPolicy>().WithMany()
                        .HasForeignKey("PolicyId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__PayrollPo__polic__7EF6D905"),
                    l => l.HasOne<Payroll>().WithMany()
                        .HasForeignKey("PayrollId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__PayrollPo__payro__7E02B4CC"),
                    j =>
                    {
                        j.HasKey("PayrollId", "PolicyId").HasName("PK__PayrollP__FDE26AB47E46B2A2");
                        j.ToTable("PayrollPolicy_ID");
                        j.HasIndex(new[] { "PayrollId" }, "IX_PayrollPolicyID_PayrollID");
                        j.HasIndex(new[] { "PolicyId" }, "IX_PayrollPolicyID_PolicyID");
                        j.IndexerProperty<int>("PayrollId").HasColumnName("payroll_id");
                        j.IndexerProperty<int>("PolicyId").HasColumnName("policy_id");
                    });
        });

        modelBuilder.Entity<PayrollLog>(entity =>
        {
            entity.HasKey(e => e.PayrollLogId).HasName("PK__Payroll___7B69DA7AF74EF2BF");

            entity.ToTable("Payroll_Log");

            entity.HasIndex(e => e.Actor, "IX_PayrollLog_Actor");

            entity.HasIndex(e => e.ChangeDate, "IX_PayrollLog_ChangeDate");

            entity.HasIndex(e => e.ModificationType, "IX_PayrollLog_ModificationType");

            entity.HasIndex(e => e.PayrollId, "IX_PayrollLog_PayrollID");

            entity.Property(e => e.PayrollLogId).HasColumnName("payroll_log_id");
            entity.Property(e => e.Actor).HasColumnName("actor");
            entity.Property(e => e.ChangeDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("change_date");
            entity.Property(e => e.ModificationType)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("modification_type");
            entity.Property(e => e.PayrollId).HasColumnName("payroll_id");

            entity.HasOne(d => d.Payroll).WithMany(p => p.PayrollLogs)
                .HasForeignKey(d => d.PayrollId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Payroll_L__payro__7FEAFD3E");
        });

        modelBuilder.Entity<PayrollPeriod>(entity =>
        {
            entity.HasKey(e => e.PayrollPeriodId).HasName("PK__PayrollP__CD8483A22716A5D8");

            entity.ToTable("PayrollPeriod");

            entity.HasIndex(e => e.EndDate, "IX_PayrollPeriod_EndDate");

            entity.HasIndex(e => e.PayrollId, "IX_PayrollPeriod_PayrollID");

            entity.HasIndex(e => e.StartDate, "IX_PayrollPeriod_StartDate");

            entity.HasIndex(e => e.Status, "IX_PayrollPeriod_Status");

            entity.Property(e => e.PayrollPeriodId).HasColumnName("payroll_period_id");
            entity.Property(e => e.EndDate).HasColumnName("end_date");
            entity.Property(e => e.PayrollId).HasColumnName("payroll_id");
            entity.Property(e => e.StartDate).HasColumnName("start_date");
            entity.Property(e => e.Status)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasDefaultValue("Open")
                .HasColumnName("status");

            entity.HasOne(d => d.Payroll).WithMany(p => p.PayrollPeriods)
                .HasForeignKey(d => d.PayrollId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__PayrollPe__payro__00DF2177");
        });

        modelBuilder.Entity<PayrollPolicy>(entity =>
        {
            entity.HasKey(e => e.PolicyId).HasName("PK__PayrollP__47DA3F03B5B1481C");

            entity.ToTable("PayrollPolicy");

            entity.HasIndex(e => e.EffectiveDate, "IX_PayrollPolicy_EffectiveDate");

            entity.HasIndex(e => e.Type, "IX_PayrollPolicy_Type");

            entity.Property(e => e.PolicyId).HasColumnName("policy_id");
            entity.Property(e => e.Description).HasColumnName("description");
            entity.Property(e => e.EffectiveDate).HasColumnName("effective_date");
            entity.Property(e => e.Type)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("type");
        });

        modelBuilder.Entity<PayrollSpecialist>(entity =>
        {
            entity.HasKey(e => e.EmployeeId).HasName("PK__PayrollS__C52E0BA829336B8A");

            entity.ToTable("PayrollSpecialist");

            entity.Property(e => e.EmployeeId)
                .ValueGeneratedNever()
                .HasColumnName("employee_id");
            entity.Property(e => e.AssignedRegion)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("assigned_region");
            entity.Property(e => e.LastProcessedPeriod).HasColumnName("last_processed_period");
            entity.Property(e => e.ProcessingFrequency)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("processing_frequency");

            entity.HasOne(d => d.Employee).WithOne(p => p.PayrollSpecialist)
                .HasForeignKey<PayrollSpecialist>(d => d.EmployeeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__PayrollSp__emplo__671F4F74");
        });

        modelBuilder.Entity<Position>(entity =>
        {
            entity.HasKey(e => e.PositionId).HasName("PK__Position__99A0E7A414BD53FE");

            entity.ToTable("Position");

            entity.HasIndex(e => e.Status, "IX_Position_Status");

            entity.HasIndex(e => e.PositionTitle, "IX_Position_Title");

            entity.Property(e => e.PositionId).HasColumnName("position_id");
            entity.Property(e => e.PositionTitle)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("position_title");
            entity.Property(e => e.Responsibilities)
                .HasMaxLength(1000)
                .IsUnicode(false)
                .HasColumnName("responsibilities");
            entity.Property(e => e.Status)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasDefaultValue("Active")
                .HasColumnName("status");
        });

        modelBuilder.Entity<ProbationLeave>(entity =>
        {
            entity.HasKey(e => e.LeaveId).HasName("PK__Probatio__743350BC3C4427AB");

            entity.ToTable("ProbationLeave");

            entity.Property(e => e.LeaveId)
                .ValueGeneratedNever()
                .HasColumnName("leave_id");
            entity.Property(e => e.EligibilityStartDate).HasColumnName("eligibility_start_date");
            entity.Property(e => e.ProbationPeriod).HasColumnName("probation_period");

            entity.HasOne(d => d.Leave).WithOne(p => p.ProbationLeave)
                .HasForeignKey<ProbationLeave>(d => d.LeaveId)
                .HasConstraintName("FK__Probation__leave__1209AD79");
        });

        modelBuilder.Entity<Reimbursement>(entity =>
        {
            entity.HasKey(e => e.ReimbursementId).HasName("PK__Reimburs__F6C2698444E11EA7");

            entity.ToTable("Reimbursement");

            entity.HasIndex(e => e.EmployeeId, "IX_Reimbursement_EmployeeID");

            entity.HasIndex(e => e.CurrentStatus, "IX_Reimbursement_Status");

            entity.HasIndex(e => e.Type, "IX_Reimbursement_Type");

            entity.Property(e => e.ReimbursementId).HasColumnName("reimbursement_id");
            entity.Property(e => e.ApprovalDate).HasColumnName("approval_date");
            entity.Property(e => e.ClaimType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("claim_type");
            entity.Property(e => e.CurrentStatus)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("current_status");
            entity.Property(e => e.EmployeeId).HasColumnName("employee_id");
            entity.Property(e => e.Type)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("type");

            entity.HasOne(d => d.Employee).WithMany(p => p.Reimbursements)
                .HasForeignKey(d => d.EmployeeId)
                .HasConstraintName("FK__Reimburse__emplo__0D44F85C");
        });

        modelBuilder.Entity<Role>(entity =>
        {
            entity.HasKey(e => e.RoleId).HasName("PK__Role__760965CC74B1186C");

            entity.ToTable("Role");

            entity.HasIndex(e => e.RoleName, "UQ__Role__783254B13513D4E2").IsUnique();

            entity.Property(e => e.RoleId).HasColumnName("role_id");
            entity.Property(e => e.Purpose)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("purpose");
            entity.Property(e => e.RoleName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("role_name");
        });

        modelBuilder.Entity<RolePermission>(entity =>
        {
            entity.HasKey(e => new { e.RoleId, e.PermissionName }).HasName("PK__RolePerm__5E156A96A51E8F20");

            entity.ToTable("RolePermission");

            entity.Property(e => e.RoleId).HasColumnName("role_id");
            entity.Property(e => e.PermissionName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("permission_name");
            entity.Property(e => e.AllowedAction)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("allowed_action");

            entity.HasOne(d => d.Role).WithMany(p => p.RolePermissions)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__RolePermi__role___690797E6");
        });

        modelBuilder.Entity<SalaryType>(entity =>
        {
            entity.HasKey(e => e.SalaryTypeId).HasName("PK__SalaryTy__4D64706202D8D424");

            entity.ToTable("SalaryType");

            entity.HasIndex(e => e.Currency, "IX_SalaryType_Currency");

            entity.HasIndex(e => e.PaymentFrequency, "IX_SalaryType_Frequency");

            entity.HasIndex(e => e.Type, "IX_SalaryType_Type");

            entity.Property(e => e.SalaryTypeId).HasColumnName("salary_type_id");
            entity.Property(e => e.Currency)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("currency");
            entity.Property(e => e.PaymentFrequency)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("payment_frequency");
            entity.Property(e => e.Type)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("type");

            entity.HasOne(d => d.CurrencyNavigation).WithMany(p => p.SalaryTypes)
                .HasForeignKey(d => d.Currency)
                .HasConstraintName("FK__SalaryTyp__curre__72910220");
        });

        modelBuilder.Entity<ShiftAssignment>(entity =>
        {
            entity.HasKey(e => e.AssignmentId).HasName("PK__ShiftAss__DA891814CBCC12AB");

            entity.ToTable("ShiftAssignment");

            entity.HasIndex(e => e.EmployeeId, "IX_ShiftAssignment_EmployeeID");

            entity.HasIndex(e => e.EndDate, "IX_ShiftAssignment_EndDate");

            entity.HasIndex(e => e.ShiftId, "IX_ShiftAssignment_ShiftID");

            entity.HasIndex(e => e.StartDate, "IX_ShiftAssignment_StartDate");

            entity.HasIndex(e => e.Status, "IX_ShiftAssignment_Status");

            entity.Property(e => e.AssignmentId).HasColumnName("assignment_id");
            entity.Property(e => e.EmployeeId).HasColumnName("employee_id");
            entity.Property(e => e.EndDate).HasColumnName("end_date");
            entity.Property(e => e.ShiftId).HasColumnName("shift_id");
            entity.Property(e => e.StartDate).HasColumnName("start_date");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("status");

            entity.HasOne(d => d.Employee).WithMany(p => p.ShiftAssignments)
                .HasForeignKey(d => d.EmployeeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ShiftAssi__emplo__18B6AB08");

            entity.HasOne(d => d.Shift).WithMany(p => p.ShiftAssignments)
                .HasForeignKey(d => d.ShiftId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ShiftAssi__shift__19AACF41");
        });

        modelBuilder.Entity<ShiftCycle>(entity =>
        {
            entity.HasKey(e => e.CycleId).HasName("PK__ShiftCyc__5D95588163E53284");

            entity.ToTable("ShiftCycle");

            entity.HasIndex(e => e.CycleName, "IX_ShiftCycle_Name");

            entity.Property(e => e.CycleId).HasColumnName("cycle_id");
            entity.Property(e => e.CycleName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("cycle_name");
            entity.Property(e => e.Description)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("description");
        });

        modelBuilder.Entity<ShiftCycleAssignment>(entity =>
        {
            entity.HasKey(e => new { e.CycleId, e.ShiftId }).HasName("PK__ShiftCyc__4A273FA365CB52B7");

            entity.ToTable("ShiftCycleAssignment");

            entity.Property(e => e.CycleId).HasColumnName("cycle_id");
            entity.Property(e => e.ShiftId).HasColumnName("shift_id");
            entity.Property(e => e.OrderNumber).HasColumnName("order_number");

            entity.HasOne(d => d.Cycle).WithMany(p => p.ShiftCycleAssignments)
                .HasForeignKey(d => d.CycleId)
                .HasConstraintName("FK__ShiftCycl__cycle__1A9EF37A");

            entity.HasOne(d => d.Shift).WithMany(p => p.ShiftCycleAssignments)
                .HasForeignKey(d => d.ShiftId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ShiftCycl__shift__1B9317B3");
        });

        modelBuilder.Entity<ShiftSchedule>(entity =>
        {
            entity.HasKey(e => e.ShiftId).HasName("PK__ShiftSch__7B267220DC9776D7");

            entity.ToTable("ShiftSchedule");

            entity.HasIndex(e => e.ShiftDate, "IX_ShiftSchedule_Date");

            entity.HasIndex(e => e.Name, "IX_ShiftSchedule_Name");

            entity.HasIndex(e => e.Status, "IX_ShiftSchedule_Status");

            entity.HasIndex(e => e.Type, "IX_ShiftSchedule_Type");

            entity.Property(e => e.ShiftId).HasColumnName("shift_id");
            entity.Property(e => e.BreakDuration)
                .HasDefaultValue(0)
                .HasColumnName("break_duration");
            entity.Property(e => e.EndTime).HasColumnName("end_time");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("name");
            entity.Property(e => e.ShiftDate).HasColumnName("shift_date");
            entity.Property(e => e.StartTime).HasColumnName("start_time");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("status");
            entity.Property(e => e.Type)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("type");
        });

        modelBuilder.Entity<SickLeave>(entity =>
        {
            entity.HasKey(e => e.LeaveId).HasName("PK__SickLeav__743350BC8680321F");

            entity.ToTable("SickLeave");

            entity.Property(e => e.LeaveId)
                .ValueGeneratedNever()
                .HasColumnName("leave_id");
            entity.Property(e => e.MedicalCertRequired)
                .HasDefaultValue(false)
                .HasColumnName("medical_cert_required");
            entity.Property(e => e.PhysicianId).HasColumnName("physician_id");

            entity.HasOne(d => d.Leave).WithOne(p => p.SickLeave)
                .HasForeignKey<SickLeave>(d => d.LeaveId)
                .HasConstraintName("FK__SickLeave__leave__11158940");
        });

        modelBuilder.Entity<Skill>(entity =>
        {
            entity.HasKey(e => e.SkillId).HasName("PK__Skill__FBBA8379277E8557");

            entity.ToTable("Skill");

            entity.HasIndex(e => e.SkillName, "IX_Skill_Name");

            entity.HasIndex(e => e.SkillName, "UQ__Skill__73C038ADE73A9905").IsUnique();

            entity.Property(e => e.SkillId).HasColumnName("skill_id");
            entity.Property(e => e.Description)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("description");
            entity.Property(e => e.SkillName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("skill_name");
        });

        modelBuilder.Entity<SystemAdministrator>(entity =>
        {
            entity.HasKey(e => e.EmployeeId).HasName("PK__SystemAd__C52E0BA83DDBC049");

            entity.ToTable("SystemAdministrator");

            entity.Property(e => e.EmployeeId)
                .ValueGeneratedNever()
                .HasColumnName("employee_id");
            entity.Property(e => e.AuditVisibilityScope)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("audit_visibility_scope");
            entity.Property(e => e.ConfigurableFields)
                .IsUnicode(false)
                .HasColumnName("configurable_fields");
            entity.Property(e => e.SystemPrivilegeLevel)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasDefaultValue("Standard")
                .HasColumnName("system_privilege_level");

            entity.HasOne(d => d.Employee).WithOne(p => p.SystemAdministrator)
                .HasForeignKey<SystemAdministrator>(d => d.EmployeeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__SystemAdm__emplo__662B2B3B");
        });

        modelBuilder.Entity<TaxForm>(entity =>
        {
            entity.HasKey(e => e.TaxFormId).HasName("PK__TaxForm__3184195AF5566A59");

            entity.ToTable("TaxForm");

            entity.HasIndex(e => e.Jurisdiction, "IX_TaxForm_Jurisdiction");

            entity.Property(e => e.TaxFormId).HasColumnName("tax_form_id");
            entity.Property(e => e.FormContent).HasColumnName("form_content");
            entity.Property(e => e.Jurisdiction)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("jurisdiction");
            entity.Property(e => e.ValidityPeriod)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("validity_period");
        });

        modelBuilder.Entity<Termination>(entity =>
        {
            entity.HasKey(e => e.TerminationId).HasName("PK__Terminat__B66BAA1133402B5A");

            entity.ToTable("Termination");

            entity.HasIndex(e => e.ContractId, "IX_Termination_ContractID");

            entity.HasIndex(e => e.Date, "IX_Termination_Date");

            entity.Property(e => e.TerminationId).HasColumnName("termination_id");
            entity.Property(e => e.ContractId).HasColumnName("contract_id");
            entity.Property(e => e.Date).HasColumnName("date");
            entity.Property(e => e.Reason)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("reason");

            entity.HasOne(d => d.Contract).WithMany(p => p.Terminations)
                .HasForeignKey(d => d.ContractId)
                .HasConstraintName("FK__Terminati__contr__0C50D423");
        });

        modelBuilder.Entity<VacationLeave>(entity =>
        {
            entity.HasKey(e => e.LeaveId).HasName("PK__Vacation__743350BCC10A6A38");

            entity.ToTable("VacationLeave");

            entity.Property(e => e.LeaveId)
                .ValueGeneratedNever()
                .HasColumnName("leave_id");
            entity.Property(e => e.ApprovingManager).HasColumnName("approving_manager");
            entity.Property(e => e.CarryOverDays).HasColumnName("carry_over_days");

            entity.HasOne(d => d.Leave).WithOne(p => p.VacationLeave)
                .HasForeignKey<VacationLeave>(d => d.LeaveId)
                .HasConstraintName("FK__VacationL__leave__10216507");
        });

        modelBuilder.Entity<Verification>(entity =>
        {
            entity.HasKey(e => e.VerificationId).HasName("PK__Verifica__24F17969EEE1D8F8");

            entity.ToTable("Verification");

            entity.HasIndex(e => e.IssueDate, "IX_Verification_IssueDate");

            entity.HasIndex(e => e.VerificationType, "IX_Verification_Type");

            entity.Property(e => e.VerificationId).HasColumnName("verification_id");
            entity.Property(e => e.ExpiryPeriod).HasColumnName("expiry_period");
            entity.Property(e => e.IssueDate).HasColumnName("issue_date");
            entity.Property(e => e.Issuer)
                .HasMaxLength(150)
                .IsUnicode(false)
                .HasColumnName("issuer");
            entity.Property(e => e.VerificationType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("verification_type");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
