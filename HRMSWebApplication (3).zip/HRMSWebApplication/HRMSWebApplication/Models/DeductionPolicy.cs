﻿using System;
using System.Collections.Generic;

namespace HRMSWebApplication.Models;

public partial class DeductionPolicy
{
    public int PolicyId { get; set; }

    public string DeductionReason { get; set; } = null!;

    public string CalculationMode { get; set; } = null!;

    public virtual PayrollPolicy Policy { get; set; } = null!;
}
