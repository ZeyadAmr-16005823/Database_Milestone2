﻿using System;
using System.Collections.Generic;

namespace HRMSWebApplication.Models;

public partial class LeaveDocument
{
    public int DocumentId { get; set; }

    public int LeaveRequestId { get; set; }

    public string FilePath { get; set; } = null!;

    public DateTime? UploadedAt { get; set; }

    public virtual LeaveRequest LeaveRequest { get; set; } = null!;
}
