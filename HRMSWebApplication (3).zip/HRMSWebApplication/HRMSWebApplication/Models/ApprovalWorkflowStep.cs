﻿using System;
using System.Collections.Generic;

namespace HRMSWebApplication.Models;

public partial class ApprovalWorkflowStep
{
    public int WorkflowId { get; set; }

    public int StepNumber { get; set; }

    public int RoleId { get; set; }

    public string? ActionRequired { get; set; }

    public virtual Role Role { get; set; } = null!;

    public virtual ApprovalWorkflow Workflow { get; set; } = null!;
}
