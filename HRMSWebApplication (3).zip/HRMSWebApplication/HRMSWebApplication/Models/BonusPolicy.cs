﻿using System;
using System.Collections.Generic;

namespace HRMSWebApplication.Models;

public partial class BonusPolicy
{
    public int PolicyId { get; set; }

    public string BonusType { get; set; } = null!;

    public string? EligibilityCriteria { get; set; }

    public virtual PayrollPolicy Policy { get; set; } = null!;
}
