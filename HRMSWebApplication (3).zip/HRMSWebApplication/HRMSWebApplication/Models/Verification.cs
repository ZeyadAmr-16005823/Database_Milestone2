﻿using System;
using System.Collections.Generic;

namespace HRMSWebApplication.Models;

public partial class Verification
{
    public int VerificationId { get; set; }

    public string VerificationType { get; set; } = null!;

    public string? Issuer { get; set; }

    public DateOnly? IssueDate { get; set; }

    public int? ExpiryPeriod { get; set; }

    public virtual ICollection<Employee> Employees { get; set; } = new List<Employee>();
}
