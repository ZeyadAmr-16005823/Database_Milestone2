﻿using System;
using System.Collections.Generic;

namespace HRMSWebApplication.Models;

public partial class AllowanceDeduction
{
    public int AdId { get; set; }

    public int PayrollId { get; set; }

    public int EmployeeId { get; set; }

    public string Type { get; set; } = null!;

    public decimal Amount { get; set; }

    public string? Currency { get; set; }

    public string? Duration { get; set; }

    public string? Timezone { get; set; }

    public virtual Currency? CurrencyNavigation { get; set; }

    public virtual Employee Employee { get; set; } = null!;

    public virtual Payroll Payroll { get; set; } = null!;
}
