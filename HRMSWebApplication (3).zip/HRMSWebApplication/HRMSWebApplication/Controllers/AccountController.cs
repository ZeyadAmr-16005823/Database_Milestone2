﻿// File: Controllers/AccountController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.Data.SqlClient;
using HRMSWebApplication.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace HRMSWebApplication.Controllers
{
    [Route("Account/[action]")]
    public class AccountController : Controller
    {
        private readonly string _connectionString;
        public AccountController(IConfiguration config) => _connectionString = config.GetConnectionString("HRMSConnection");

        private string HashPassword(string password)
        {
            if (string.IsNullOrEmpty(password)) return string.Empty;
            using var sha = SHA256.Create();
            return Convert.ToBase64String(sha.ComputeHash(Encoding.UTF8.GetBytes(password)));
        }

        private bool IsAdmin() => HttpContext.Session.GetString("Role") == "System Administrator";
        private bool IsHR() => HttpContext.Session.GetString("Role") == "HR Administrator";

        // -------------------------
        // Test access (debug)
        // -------------------------
        [HttpGet]
        public IActionResult TestAccess()
        {
            return Json(new
            {
                LoggedInEmployeeID = HttpContext.Session.GetInt32("EmployeeID"),
                Role = HttpContext.Session.GetString("Role"),
                FullName = HttpContext.Session.GetString("FullName"),
                Email = HttpContext.Session.GetString("Email")
            });
        }

        // -------------------------
        // Login
        // -------------------------
        [HttpGet]
        public IActionResult Login() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(LoginViewModel model)
        {
            if (model == null || !ModelState.IsValid) return View(model);

            try
            {
                using var conn = new SqlConnection(_connectionString);
                conn.Open();

                // Query to find highest-priority role for the user (1 = highest)
                string sql = @"
                    SELECT TOP 1 e.employee_id, e.first_name, e.last_name, e.email,
                      r.role_name,
                      CASE
                        WHEN r.role_name = 'System Administrator' THEN 1
                        WHEN r.role_name = 'HR Administrator' THEN 2
                        WHEN r.role_name = 'Manager' THEN 3
                        WHEN r.role_name = 'Employee' THEN 4
                        ELSE 99
                      END AS role_rank
                    FROM Employee e
                    LEFT JOIN Employee_Role er ON e.employee_id = er.employee_id
                    LEFT JOIN Role r ON er.role_id = r.role_id
                    WHERE e.email = @Email AND e.password_hash = @PasswordHash AND e.is_active = 1
                    ORDER BY role_rank";

                using var cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Email", model.Email ?? string.Empty);
                cmd.Parameters.AddWithValue("@PasswordHash", HashPassword(model.Password));

                using var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    int empId = reader["employee_id"] != DBNull.Value ? Convert.ToInt32(reader["employee_id"]) : -1;
                    string first = reader["first_name"]?.ToString() ?? "";
                    string last = reader["last_name"]?.ToString() ?? "";
                    string email = reader["email"]?.ToString() ?? "";
                    string role = reader["role_name"]?.ToString() ?? "Employee";

                    HttpContext.Session.SetInt32("EmployeeID", empId);
                    HttpContext.Session.SetString("FullName", (first + " " + last).Trim());
                    HttpContext.Session.SetString("Email", email);
                    HttpContext.Session.SetString("Role", role);

                    return RedirectToAction("Index", "Home");
                }

                ModelState.AddModelError(string.Empty, "Invalid email or password.");
                return View(model);
            }
            catch (System.Exception ex)
            {
                ModelState.AddModelError(string.Empty, "Login failed: " + ex.Message);
                return View(model);
            }
        }

        // -------------------------
        // Register
        // -------------------------
        [HttpGet]
        public IActionResult Register() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register(RegisterViewModel model)
        {
            if (model == null || !ModelState.IsValid) return View(model);

            try
            {
                using var conn = new SqlConnection(_connectionString);
                conn.Open();

                // defensive: ensure password_hash exists
                using (var check = new SqlCommand("SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='Employee' AND COLUMN_NAME='password_hash'", conn))
                {
                    var exists = check.ExecuteScalar();
                    if (exists == null)
                    {
                        ModelState.AddModelError(string.Empty, "Database missing required column 'password_hash'. Run migration.");
                        return View(model);
                    }
                }

                string hashed = HashPassword(model.Password);

                string sql = @"
                    INSERT INTO Employee
                      (first_name,last_name,full_name,email,phone,address,date_of_birth,password_hash,employment_progress,account_status,employment_status,hire_date,is_active,profile_completion)
                    VALUES
                      (@F,@L,@Full,@Email,@Phone,@Address,@DOB,@Pwd,'In Progress','Active','Active',GETDATE(),1,30);
                    SELECT SCOPE_IDENTITY();";

                using var cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@F", model.FirstName ?? string.Empty);
                cmd.Parameters.AddWithValue("@L", model.LastName ?? string.Empty);
                cmd.Parameters.AddWithValue("@Full", (model.FirstName ?? "") + " " + (model.LastName ?? ""));
                cmd.Parameters.AddWithValue("@Email", model.Email ?? string.Empty);
                cmd.Parameters.AddWithValue("@Phone", model.PhoneNumber ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Address", model.Address ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@DOB", model.DateOfBirth ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Pwd", hashed);

                object idObj = cmd.ExecuteScalar();
                if (idObj == null) throw new System.Exception("Failed to create user.");
                int newId = Convert.ToInt32(idObj);

                // assign Employee role
                using var getRole = new SqlCommand("SELECT role_id FROM Role WHERE role_name = @R", conn);
                getRole.Parameters.AddWithValue("@R", "Employee");
                object roleObj = getRole.ExecuteScalar();
                if (roleObj == null) throw new System.Exception("Role 'Employee' not found.");
                int roleId = Convert.ToInt32(roleObj);

                using var assign = new SqlCommand("INSERT INTO Employee_Role (employee_id, role_id, assigned_date) VALUES (@E,@R,GETDATE())", conn);
                assign.Parameters.AddWithValue("@E", newId);
                assign.Parameters.AddWithValue("@R", roleId);
                assign.ExecuteNonQuery();

                TempData["Success"] = "Account created. Please login.";
                return RedirectToAction("Login");
            }
            catch (System.Exception ex)
            {
                ModelState.AddModelError(string.Empty, "Registration failed: " + ex.Message);
                return View(model);
            }
        }

        // -------------------------
        // CreateEmployee (Admin only)
        // -------------------------
        [HttpGet]
        public IActionResult CreateEmployee()
        {
            if (!IsAdmin()) return Unauthorized();

            // populate dropdowns for view
            ViewBag.Departments = GetDataTable("SELECT department_id, department_name FROM Department");
            ViewBag.Positions = GetDataTable("SELECT position_id, position_title FROM Position");
            ViewBag.Managers = GetDataTable("SELECT employee_id, full_name FROM Employee");

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CreateEmployee(CreateEmployeeViewModel model)
        {
            if (!IsAdmin()) return Unauthorized();
            if (model == null || !ModelState.IsValid) return View(model);

            try
            {
                using var conn = new SqlConnection(_connectionString);
                conn.Open();

                string hashed = HashPassword(model.Password);

                string sql = @"
                    INSERT INTO Employee (first_name,last_name,full_name,email,national_id,date_of_birth,country_of_birth,phone,address,password_hash,department_id,position_id,manager_id,hire_date,is_active,profile_completion)
                    VALUES (@F,@L,@Full,@Email,@NID,@DOB,@COB,@Phone,@Addr,@Pwd,@Dept,@Pos,@Mgr,@Hire,1,100);
                    SELECT SCOPE_IDENTITY();";

                using var cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@F", model.FirstName ?? string.Empty);
                cmd.Parameters.AddWithValue("@L", model.LastName ?? string.Empty);
                cmd.Parameters.AddWithValue("@Full", (model.FirstName ?? "") + " " + (model.LastName ?? ""));
                cmd.Parameters.AddWithValue("@Email", model.Email ?? string.Empty);
                cmd.Parameters.AddWithValue("@NID", model.NationalID ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@DOB", model.DateOfBirth ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@COB", model.CountryOfBirth ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Phone", model.PhoneNumber ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Addr", model.Address ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Pwd", hashed);
                cmd.Parameters.AddWithValue("@Dept", model.DepartmentID ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Pos", model.PositionID ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Mgr", model.ManagerID ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Hire", model.HireDate ?? (object)DBNull.Value);

                object idObj = cmd.ExecuteScalar();
                if (idObj == null) throw new System.Exception("Failed to create employee.");
                int newId = Convert.ToInt32(idObj);

                // assign selected role
                using var getRole = new SqlCommand("SELECT role_id FROM Role WHERE role_name = @R", conn);
                getRole.Parameters.AddWithValue("@R", model.Role ?? "Employee");
                object roleObj = getRole.ExecuteScalar();
                if (roleObj == null) throw new System.Exception($"Role '{model.Role}' not found.");
                int roleId = Convert.ToInt32(roleObj);

                using var assign = new SqlCommand("INSERT INTO Employee_Role (employee_id, role_id, assigned_date) VALUES (@E,@R,GETDATE())", conn);
                assign.Parameters.AddWithValue("@E", newId);
                assign.Parameters.AddWithValue("@R", roleId);
                assign.ExecuteNonQuery();

                TempData["SuccessMessage"] = "Employee created.";
                return RedirectToAction("CreateEmployee");
            }
            catch (System.Exception ex)
            {
                ModelState.AddModelError(string.Empty, "Create employee failed: " + ex.Message);
                // re-populate viewbags in case of error
                ViewBag.Departments = GetDataTable("SELECT department_id, department_name FROM Department");
                ViewBag.Positions = GetDataTable("SELECT position_id, position_title FROM Position");
                ViewBag.Managers = GetDataTable("SELECT employee_id, full_name FROM Employee");
                return View(model);
            }
        }

        // -------------------------
        // EditProfile
        // -------------------------
        [HttpGet]
        public IActionResult EditProfile(int? id)
        {
            int currentId = HttpContext.Session.GetInt32("EmployeeID") ?? -1;

            if (id == null) id = currentId;
            if (id != currentId && !IsHR()) return Unauthorized();

            try
            {
                using SqlConnection conn = new SqlConnection(_connectionString);
                conn.Open();

                string sql = @"
            SELECT employee_id, first_name, last_name, email,
                   date_of_birth, phone, address,
                   emergency_contact_name, emergency_contact_phone, relationship,
                   profile_image, profile_completion
            FROM Employee
            WHERE employee_id = @ID";

                using SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@ID", id);

                using SqlDataReader r = cmd.ExecuteReader();
                if (!r.Read())
                {
                    TempData["Error"] = "Employee not found.";
                    return RedirectToAction("Index", "Home");
                }

                var vm = new EditProfileViewModel
                {
                    EmployeeID = (int)id,
                    FirstName = r["first_name"]?.ToString(),
                    LastName = r["last_name"]?.ToString(),
                    Email = r["email"]?.ToString(),
                    DateOfBirth = r["date_of_birth"] == DBNull.Value ? null : (DateTime?)r["date_of_birth"],
                    PhoneNumber = r["phone"]?.ToString(),
                    Address = r["address"]?.ToString(),

                    EmergencyContactName = r["emergency_contact_name"]?.ToString(),
                    EmergencyContactPhone = r["emergency_contact_phone"]?.ToString(),
                    EmergencyContactRelation = r["relationship"]?.ToString(),   // FIXED

                    ProfileImagePath = r["profile_image"]?.ToString(),          // FIXED
                    ProfileCompletion = r["profile_completion"] == DBNull.Value ? 0 : (int)r["profile_completion"]
                };

                return View(vm);
            }
            catch (System.Exception ex)
            {
                TempData["Error"] = ex.Message;
                return RedirectToAction("Index", "Home");
            }
        }



        [HttpPost]
        public IActionResult EditProfile(EditProfileViewModel model)
        {
            int currentId = HttpContext.Session.GetInt32("EmployeeID") ?? -1;

            if (model.EmployeeID != currentId && !IsHR())
                return Unauthorized();
            if (!ModelState.IsValid)
                return View(model);

            try
            {
                using SqlConnection conn = new SqlConnection(_connectionString);
                conn.Open();

                string sql = @"UPDATE Employee
                       SET first_name=@F, last_name=@L, email=@E, 
                           date_of_birth=@DOB, phone=@P, address=@A,
                           emergency_contact_name=@ECN,
                           emergency_contact_phone=@ECP,
                           emergency_contact_relation=@ECR
                       WHERE employee_id=@ID";

                using SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@F", model.FirstName ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@L", model.LastName ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@E", model.Email ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@DOB", model.DateOfBirth ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@P", model.PhoneNumber ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@A", model.Address ?? (object)DBNull.Value);

                cmd.Parameters.AddWithValue("@ECN", model.EmergencyContactName ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@ECP", model.EmergencyContactPhone ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@ECR", model.EmergencyContactRelation ?? (object)DBNull.Value);

                cmd.Parameters.AddWithValue("@ID", model.EmployeeID);

                cmd.ExecuteNonQuery();

                TempData["Success"] = "Profile updated successfully!";
                return RedirectToAction("EditProfile", new { id = model.EmployeeID });
            }
            catch (System.Exception ex)
            {
                TempData["Error"] = ex.Message;
                return View(model);
            }
        }


        // -------------------------
        // Upload picture
        // -------------------------
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult UploadProfilePicture(IFormFile picture)
        {
            int id = HttpContext.Session.GetInt32("EmployeeID") ?? -1;
            if (id == -1) return Unauthorized();
            if (picture == null || picture.Length == 0)
            {
                TempData["Error"] = "No file selected.";
                return RedirectToAction("EditProfile");
            }

            string safeFileName = Path.GetFileName(picture.FileName);
            string outFileName = $"{id}_{Guid.NewGuid():N}_{safeFileName}";
            string folder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "ProfilePictures");

            try
            {
                if (!Directory.Exists(folder)) Directory.CreateDirectory(folder);
                string filePath = Path.Combine(folder, outFileName);
                using var stream = new FileStream(filePath, FileMode.Create);
                picture.CopyTo(stream);

                using var conn = new SqlConnection(_connectionString);
                conn.Open();
                using var cmd = new SqlCommand("UPDATE Employee SET profile_picture = @Pic WHERE employee_id = @ID", conn);
                cmd.Parameters.AddWithValue("@Pic", "/ProfilePictures/" + outFileName);
                cmd.Parameters.AddWithValue("@ID", id);
                cmd.ExecuteNonQuery();

                TempData["Success"] = "Profile picture updated.";
                return RedirectToAction("EditProfile");
            }
            catch (System.Exception ex)
            {
                ModelState.AddModelError(string.Empty, "Upload failed: " + ex.Message);
                return RedirectToAction("EditProfile");
            }
        }

        // -------------------------
        // Logout (GET)
        // -------------------------
        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }

        // -------------------------
        // Helper: read a SQL into DataTable
        // -------------------------
        private DataTable GetDataTable(string sql)
        {
            var dt = new DataTable();
            using var conn = new SqlConnection(_connectionString);
            using var cmd = new SqlCommand(sql, conn);
            conn.Open();
            using var reader = cmd.ExecuteReader();
            dt.Load(reader);
            return dt;
        }
    }
}
