﻿// File: Controllers/DiagnosticController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;

namespace HRMSWebApplication.Controllers
{
    [Route("diag")]
    public class DiagnosticController : Controller
    {
        private readonly IConfiguration _config;
        public DiagnosticController(IConfiguration config) { _config = config; }

        [HttpGet("db")]
        public IActionResult Db()
        {
            var info = new Dictionary<string, object>();
            try
            {
                string cs = _config.GetConnectionString("HRMSConnection") ?? "(none)";
                info["ConnectionString"] = cs;

                using (var conn = new SqlConnection(cs))
                {
                    conn.Open();
                    info["Database"] = conn.Database;

                    // list tables
                    var tables = new List<string>();
                    using (var tcmd = new SqlCommand(
                        "SELECT TABLE_SCHEMA + '.' + TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE='BASE TABLE' ORDER BY TABLE_SCHEMA, TABLE_NAME", conn))
                    using (var r = tcmd.ExecuteReader())
                    {
                        while (r.Read()) tables.Add(r.GetString(0));
                    }
                    info["Tables"] = tables;

                    // list Employee columns (if any)
                    var cols = new List<string>();
                    using (var ccmd = new SqlCommand(
                        "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Employee' ORDER BY ORDINAL_POSITION", conn))
                    using (var r2 = ccmd.ExecuteReader())
                    {
                        while (r2.Read()) cols.Add(r2.GetString(0));
                    }
                    info["EmployeeColumns"] = cols;
                }

                return Json(info);
            }
            catch (Exception ex)
            {
                info["Error"] = ex.Message;
                return Json(info);
            }
        }
    }
}
