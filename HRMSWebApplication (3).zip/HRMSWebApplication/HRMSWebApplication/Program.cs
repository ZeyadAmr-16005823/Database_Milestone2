// File: Program.cs
using Microsoft.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromHours(2);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});
var app = builder.Build();

if (!app.Environment.IsDevelopment()) app.UseExceptionHandler("/Home/Error");

app.UseStaticFiles();
app.UseRouting();
app.UseSession();
app.UseAuthorization();

// Force root URL to Login
app.Use(async (context, next) =>
{
    if (context.Request.Path == "/")
    {
        context.Response.Redirect("/Account/Login");
        return;
    }
    await next();
});

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Account}/{action=Login}/{id?}"
);

// seed (same as before)
void SeedRolesAndAdmin(string connectionString)
{
    try
    {
        using var conn = new SqlConnection(connectionString);
        conn.Open();

        string[] roles = { "System Administrator", "HR Administrator", "Manager", "Employee" };
        foreach (var r in roles)
        {
            using var check = new SqlCommand("IF NOT EXISTS (SELECT 1 FROM Role WHERE role_name=@R) INSERT INTO Role (role_name) VALUES (@R);", conn);
            check.Parameters.AddWithValue("@R", r);
            check.ExecuteNonQuery();
        }

        string adminEmail = "admin@example.com";
        string adminPassword = "Admin@123";
        using var find = new SqlCommand("SELECT employee_id FROM Employee WHERE email = @E", conn);
        find.Parameters.AddWithValue("@E", adminEmail);
        var exists = find.ExecuteScalar();
        if (exists == null)
        {
            string hashed = Convert.ToBase64String(SHA256.Create().ComputeHash(Encoding.UTF8.GetBytes(adminPassword)));
            using var insert = new SqlCommand(@"
                INSERT INTO Employee (first_name,last_name,full_name,email,password_hash,hire_date,is_active,profile_completion)
                VALUES ('System','Admin','System Admin',@E,@P,GETDATE(),1,100);
                SELECT SCOPE_IDENTITY();", conn);
            insert.Parameters.AddWithValue("@E", adminEmail);
            insert.Parameters.AddWithValue("@P", hashed);
            var idObj = insert.ExecuteScalar();
            if (idObj != null)
            {
                int id = Convert.ToInt32(idObj);
                using var getRole = new SqlCommand("SELECT role_id FROM Role WHERE role_name = 'System Administrator'", conn);
                var rid = getRole.ExecuteScalar();
                if (rid != null)
                {
                    using var assign = new SqlCommand("INSERT INTO Employee_Role (employee_id, role_id, assigned_date) VALUES (@E,@R,GETDATE())", conn);
                    assign.Parameters.AddWithValue("@E", id);
                    assign.Parameters.AddWithValue("@R", Convert.ToInt32(rid));
                    assign.ExecuteNonQuery();
                }
            }
        }
    }
    catch
    {
        // ignore
    }
}

try
{
    var connStr = app.Configuration.GetConnectionString("HRMSConnection");
    if (!string.IsNullOrEmpty(connStr)) SeedRolesAndAdmin(connStr);
}
catch { }

app.Run();
