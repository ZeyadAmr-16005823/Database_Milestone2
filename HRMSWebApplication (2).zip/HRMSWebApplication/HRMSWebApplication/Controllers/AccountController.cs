﻿// File: Controllers/AccountController.cs
// ASP.NET CORE VERSION

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.Data.SqlClient;
using System;
using System.Data;
using System.Security.Cryptography;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Linq;
using HRMSWebApplication.Models;
using SystemException = System.Exception; 

namespace HRMSWebApplication.Controllers
{
    public class AccountController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _environment;
        private string connectionString;

        public AccountController(IConfiguration configuration, IWebHostEnvironment environment)
        {
            _configuration = configuration;
            _environment = environment;
            connectionString = _configuration.GetConnectionString("HRMSConnection");
        }

        // ==================== REGISTER ====================

        // GET: Register
        public IActionResult Register()
        {
            return View();
        }

        // POST: Register
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();

                        // Check if email exists
                        SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM Employee WHERE email = @Email", conn);
                        checkCmd.Parameters.AddWithValue("@Email", model.Email);
                        int count = (int)checkCmd.ExecuteScalar();

                        if (count > 0)
                        {
                            ModelState.AddModelError("", "Email already exists");
                            return View(model);
                        }

                        // Get role_id
                        SqlCommand roleCmd = new SqlCommand("SELECT role_id FROM Role WHERE role_name = @Role", conn);
                        roleCmd.Parameters.AddWithValue("@Role", model.Role);
                        object roleIdObj = roleCmd.ExecuteScalar();

                        if (roleIdObj == null)
                        {
                            ModelState.AddModelError("", "Invalid role selected");
                            return View(model);
                        }

                        int roleId = Convert.ToInt32(roleIdObj);
                        string fullName = model.FirstName + " " + model.LastName;
                        string hashedPassword = HashPassword(model.Password);

                        // Insert employee
                        string insertSql = @"INSERT INTO Employee (first_name, last_name, full_name, email, phone, 
                                           date_of_birth, address, biography, employment_progress, account_status, 
                                           employment_status, hire_date, is_active, profile_completion) 
                                           VALUES (@FirstName, @LastName, @FullName, @Email, @Phone, @DOB, @Address, 
                                           @Password, 'In Progress', 'Active', 'Active', GETDATE(), 1, 30);
                                           SELECT CAST(SCOPE_IDENTITY() AS INT);";

                        SqlCommand insertCmd = new SqlCommand(insertSql, conn);
                        insertCmd.Parameters.AddWithValue("@FirstName", model.FirstName);
                        insertCmd.Parameters.AddWithValue("@LastName", model.LastName);
                        insertCmd.Parameters.AddWithValue("@FullName", fullName);
                        insertCmd.Parameters.AddWithValue("@Email", model.Email);
                        insertCmd.Parameters.AddWithValue("@Phone", model.PhoneNumber ?? (object)DBNull.Value);
                        insertCmd.Parameters.AddWithValue("@DOB", model.DateOfBirth.HasValue ? (object)model.DateOfBirth.Value : DBNull.Value);
                        insertCmd.Parameters.AddWithValue("@Address", model.Address ?? (object)DBNull.Value);
                        insertCmd.Parameters.AddWithValue("@Password", hashedPassword);

                        int newEmployeeId = (int)insertCmd.ExecuteScalar();

                        // Assign role
                        SqlCommand roleAssignCmd = new SqlCommand(
                            "INSERT INTO Employee_Role (employee_id, role_id, assigned_date) VALUES (@EmpId, @RoleId, GETDATE())", conn);
                        roleAssignCmd.Parameters.AddWithValue("@EmpId", newEmployeeId);
                        roleAssignCmd.Parameters.AddWithValue("@RoleId", roleId);
                        roleAssignCmd.ExecuteNonQuery();

                        TempData["SuccessMessage"] = "Account created successfully! Please log in.";
                        return RedirectToAction("Login");
                    }
                }
                catch (System.Exception ex)
                {
                    ModelState.AddModelError("", "Registration failed: " + ex.Message);
                }
            }

            return View(model);
        }

        // ==================== LOGIN ====================

        // GET: Login
        public IActionResult Login()
        {
            return View();
        }

        // POST: Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();

                        string hashedPassword = HashPassword(model.Password);

                        string sql = @"SELECT e.employee_id, e.first_name, e.last_name, e.email, r.role_name
                                     FROM Employee e
                                     LEFT JOIN Employee_Role er ON e.employee_id = er.employee_id
                                     LEFT JOIN Role r ON er.role_id = r.role_id
                                     WHERE e.email = @Email AND e.biography = @Password AND e.is_active = 1";

                        SqlCommand cmd = new SqlCommand(sql, conn);
                        cmd.Parameters.AddWithValue("@Email", model.Email);
                        cmd.Parameters.AddWithValue("@Password", hashedPassword);

                        SqlDataReader reader = cmd.ExecuteReader();

                        if (reader.Read())
                        {
                            // Store in session
                            HttpContext.Session.SetInt32("EmployeeID", Convert.ToInt32(reader["employee_id"]));
                            HttpContext.Session.SetString("FullName", reader["first_name"].ToString() + " " + reader["last_name"].ToString());
                            HttpContext.Session.SetString("Email", reader["email"].ToString());
                            HttpContext.Session.SetString("Role", reader["role_name"] != DBNull.Value ? reader["role_name"].ToString() : "Employee");

                            TempData["SuccessMessage"] = "Login successful!";
                            return RedirectToAction("Index", "Home");
                        }
                        else
                        {
                            ModelState.AddModelError("", "Invalid email or password");
                        }
                    }
                }
                catch (System.Exception ex)
                {
                    ModelState.AddModelError("", "Login failed: " + ex.Message);
                }
            }

            return View(model);
        }

        // ==================== LOGOUT ====================

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            TempData["SuccessMessage"] = "You have been logged out successfully.";
            return RedirectToAction("Login");
        }

        // ==================== CREATE EMPLOYEE (ADMIN) ====================

        // GET: CreateEmployee
        [HttpGet]
        public IActionResult CreateEmployee()
        {
            if (!IsLoggedIn() || !IsAdmin())
            {
                TempData["ErrorMessage"] = "Access denied. Only Admins can create employees.";
                return RedirectToAction("Index", "Home");
            }

            LoadDropdowns();
            return View();
        }

        // POST: CreateEmployee
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CreateEmployee(CreateEmployeeViewModel model)
        {
            if (!IsLoggedIn() || !IsAdmin())
            {
                TempData["ErrorMessage"] = "Access denied.";
                return RedirectToAction("Index", "Home");
            }

            if (ModelState.IsValid)
            {
                try
                {
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        using (SqlCommand cmd = new SqlCommand("AddEmployee", conn))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;

                            string fullName = model.FirstName + " " + model.LastName;
                            string hashedPassword = HashPassword(model.Password);

                            cmd.Parameters.AddWithValue("@FullName", fullName);
                            cmd.Parameters.AddWithValue("@NationalID", model.NationalID ?? (object)DBNull.Value);
                            cmd.Parameters.AddWithValue("@DateOfBirth", model.DateOfBirth.HasValue ? (object)model.DateOfBirth.Value : DBNull.Value);
                            cmd.Parameters.AddWithValue("@CountryOfBirth", model.CountryOfBirth ?? (object)DBNull.Value);
                            cmd.Parameters.AddWithValue("@Phone", model.PhoneNumber ?? (object)DBNull.Value);
                            cmd.Parameters.AddWithValue("@Email", model.Email);
                            cmd.Parameters.AddWithValue("@Address", model.Address ?? (object)DBNull.Value);
                            cmd.Parameters.AddWithValue("@EmergencyContactName", DBNull.Value);
                            cmd.Parameters.AddWithValue("@EmergencyContactPhone", DBNull.Value);
                            cmd.Parameters.AddWithValue("@Relationship", DBNull.Value);
                            cmd.Parameters.AddWithValue("@Biography", hashedPassword);
                            cmd.Parameters.AddWithValue("@EmploymentProgress", "Completed");
                            cmd.Parameters.AddWithValue("@AccountStatus", "Active");
                            cmd.Parameters.AddWithValue("@EmploymentStatus", "Active");
                            cmd.Parameters.AddWithValue("@HireDate", model.HireDate.HasValue ? (object)model.HireDate.Value : DateTime.Now);
                            cmd.Parameters.AddWithValue("@IsActive", true);
                            cmd.Parameters.AddWithValue("@ProfileCompletion", 50);
                            cmd.Parameters.AddWithValue("@DepartmentID", model.DepartmentID);
                            cmd.Parameters.AddWithValue("@PositionID", model.PositionID ?? (object)DBNull.Value);
                            cmd.Parameters.AddWithValue("@ManagerID", model.ManagerID ?? (object)DBNull.Value);
                            cmd.Parameters.AddWithValue("@ContractID", DBNull.Value);
                            cmd.Parameters.AddWithValue("@TaxFormID", DBNull.Value);
                            cmd.Parameters.AddWithValue("@SalaryTypeID", DBNull.Value);
                            cmd.Parameters.AddWithValue("@PayGrade", DBNull.Value);

                            conn.Open();
                            SqlDataReader reader = cmd.ExecuteReader();

                            if (reader.Read())
                            {
                                int newEmployeeId = Convert.ToInt32(reader["EmployeeID"]);
                                reader.Close();

                                // Assign role
                                SqlCommand roleCmd = new SqlCommand("SELECT role_id FROM Role WHERE role_name = @Role", conn);
                                roleCmd.Parameters.AddWithValue("@Role", model.Role);
                                object roleIdObj = roleCmd.ExecuteScalar();

                                if (roleIdObj != null)
                                {
                                    SqlCommand assignCmd = new SqlCommand(
                                        "INSERT INTO Employee_Role (employee_id, role_id, assigned_date) VALUES (@EmpId, @RoleId, GETDATE())", conn);
                                    assignCmd.Parameters.AddWithValue("@EmpId", newEmployeeId);
                                    assignCmd.Parameters.AddWithValue("@RoleId", roleIdObj);
                                    assignCmd.ExecuteNonQuery();
                                }

                                TempData["SuccessMessage"] = "Employee created successfully!";
                                return RedirectToAction("CreateEmployee");
                            }
                        }
                    }
                }
                catch (System.Exception ex)
                {
                    ModelState.AddModelError("", "Failed to create employee: " + ex.Message);
                }
            }

            LoadDropdowns();
            return View(model);
        }

        // ==================== EDIT PROFILE ====================

        // GET: EditProfile
        [HttpGet]
        public IActionResult EditProfile(int? id)
        {
            if (!IsLoggedIn())
            {
                return RedirectToAction("Login");
            }

            int employeeId;

            // HR Admin can edit any profile
            if (IsHRAdmin() && id.HasValue)
            {
                employeeId = id.Value;
            }
            else
            {
                employeeId = HttpContext.Session.GetInt32("EmployeeID") ?? 0;
            }

            EditProfileViewModel model = GetEmployeeProfile(employeeId);

            if (model == null)
            {
                TempData["ErrorMessage"] = "Employee not found.";
                return RedirectToAction("Index", "Home");
            }

            return View(model);
        }

        // POST: EditProfile
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditProfile(EditProfileViewModel model)
        {
            if (!IsLoggedIn())
            {
                return RedirectToAction("Login");
            }

            // Check permission
            int currentEmployeeId = HttpContext.Session.GetInt32("EmployeeID") ?? 0;
            if (!IsHRAdmin() && currentEmployeeId != model.EmployeeID)
            {
                TempData["ErrorMessage"] = "Access denied.";
                return RedirectToAction("Index", "Home");
            }

            if (ModelState.IsValid)
            {
                try
                {
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();

                        // Use UpdateEmployeeInfo procedure
                        using (SqlCommand cmd = new SqlCommand("UpdateEmployeeInfo", conn))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@EmployeeID", model.EmployeeID);
                            cmd.Parameters.AddWithValue("@Email", model.Email);
                            cmd.Parameters.AddWithValue("@Phone", model.PhoneNumber ?? (object)DBNull.Value);
                            cmd.Parameters.AddWithValue("@Address", model.Address ?? (object)DBNull.Value);
                            cmd.ExecuteNonQuery();
                        }

                        // Update additional fields
                        string updateSql = @"UPDATE Employee SET 
                                           first_name = @FirstName, 
                                           last_name = @LastName,
                                           full_name = @FullName,
                                           date_of_birth = @DOB,
                                           emergency_contact_name = @EmgName,
                                           emergency_contact_phone = @EmgPhone,
                                           relationship = @Relation
                                           WHERE employee_id = @EmpId";

                        SqlCommand updateCmd = new SqlCommand(updateSql, conn);
                        updateCmd.Parameters.AddWithValue("@FirstName", model.FirstName);
                        updateCmd.Parameters.AddWithValue("@LastName", model.LastName);
                        updateCmd.Parameters.AddWithValue("@FullName", model.FirstName + " " + model.LastName);
                        updateCmd.Parameters.AddWithValue("@DOB", model.DateOfBirth.HasValue ? (object)model.DateOfBirth.Value : DBNull.Value);
                        updateCmd.Parameters.AddWithValue("@EmgName", model.EmergencyContactName ?? (object)DBNull.Value);
                        updateCmd.Parameters.AddWithValue("@EmgPhone", model.EmergencyContactPhone ?? (object)DBNull.Value);
                        updateCmd.Parameters.AddWithValue("@Relation", model.EmergencyContactRelation ?? (object)DBNull.Value);
                        updateCmd.Parameters.AddWithValue("@EmpId", model.EmployeeID);
                        updateCmd.ExecuteNonQuery();
                    }

                    TempData["SuccessMessage"] = "Profile updated successfully!";
                    return RedirectToAction("EditProfile", new { id = model.EmployeeID });
                }
                catch (System.Exception ex)
                {
                    ModelState.AddModelError("", "Failed to update profile: " + ex.Message);
                }
            }

            return View(model);
        }

        // ==================== UPLOAD PROFILE PICTURE (BONUS) ====================

        [HttpGet]
        public IActionResult UploadProfilePicture()
        {
            if (!IsLoggedIn())
            {
                return RedirectToAction("Login");
            }
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UploadProfilePicture(IFormFile profilePicture)
        {
            if (!IsLoggedIn())
            {
                return RedirectToAction("Login");
            }

            if (profilePicture != null && profilePicture.Length > 0)
            {
                try
                {
                    var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif" };
                    var extension = Path.GetExtension(profilePicture.FileName).ToLower();

                    if (!allowedExtensions.Contains(extension))
                    {
                        TempData["ErrorMessage"] = "Invalid file type.";
                        return View();
                    }

                    if (profilePicture.Length > 5 * 1024 * 1024)
                    {
                        TempData["ErrorMessage"] = "File too large (max 5MB).";
                        return View();
                    }

                    int employeeId = HttpContext.Session.GetInt32("EmployeeID") ?? 0;
                    string fileName = employeeId.ToString() + "_" + Guid.NewGuid().ToString() + extension;
                    string uploadPath = Path.Combine(_environment.WebRootPath, "ProfilePictures");

                    if (!Directory.Exists(uploadPath))
                    {
                        Directory.CreateDirectory(uploadPath);
                    }

                    string filePath = Path.Combine(uploadPath, fileName);

                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await profilePicture.CopyToAsync(stream);
                    }

                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        string sql = "UPDATE Employee SET profile_image = @Path WHERE employee_id = @EmpId";
                        SqlCommand cmd = new SqlCommand(sql, conn);
                        cmd.Parameters.AddWithValue("@Path", "/ProfilePictures/" + fileName);
                        cmd.Parameters.AddWithValue("@EmpId", employeeId);

                        conn.Open();
                        cmd.ExecuteNonQuery();
                    }

                    TempData["SuccessMessage"] = "Profile picture uploaded!";
                    return RedirectToAction("EditProfile");
                }
                catch (System.Exception ex)
                {
                    TempData["ErrorMessage"] = "Upload failed: " + ex.Message;
                }
            }
            else
            {
                TempData["ErrorMessage"] = "Please select a file.";
            }

            return View();
        }

        // ==================== HELPER METHODS ====================

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(bytes);
            }
        }

        private bool IsLoggedIn()
        {
            return HttpContext.Session.GetInt32("EmployeeID").HasValue;
        }

        private bool IsAdmin()
        {
            string role = HttpContext.Session.GetString("Role");
            return role != null && (role.Contains("System Administrator") || role.Contains("Administrator"));
        }

        private bool IsHRAdmin()
        {
            string role = HttpContext.Session.GetString("Role");
            return role != null && role.Contains("HR Administrator");
        }

        private void LoadDropdowns()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                // Departments
                SqlCommand deptCmd = new SqlCommand("SELECT department_id, department_name FROM Department", conn);
                DataTable dtDept = new DataTable();
                new SqlDataAdapter(deptCmd).Fill(dtDept);
                ViewBag.Departments = dtDept;

                // Managers
                SqlCommand mgrCmd = new SqlCommand(@"SELECT DISTINCT e.employee_id, e.full_name 
                                                    FROM Employee e
                                                    INNER JOIN Employee_Role er ON e.employee_id = er.employee_id
                                                    INNER JOIN Role r ON er.role_id = r.role_id
                                                    WHERE r.role_name LIKE '%Manager%' OR r.role_name LIKE '%Administrator%'", conn);
                DataTable dtMgr = new DataTable();
                new SqlDataAdapter(mgrCmd).Fill(dtMgr);
                ViewBag.Managers = dtMgr;

                // Positions
                SqlCommand posCmd = new SqlCommand("SELECT position_id, position_title FROM Position", conn);
                DataTable dtPos = new DataTable();
                new SqlDataAdapter(posCmd).Fill(dtPos);
                ViewBag.Positions = dtPos;
            }
        }

        private EditProfileViewModel GetEmployeeProfile(int employeeId)
        {
            EditProfileViewModel model = null;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string sql = @"SELECT employee_id, first_name, last_name, email, phone, date_of_birth, 
                              address, emergency_contact_name, emergency_contact_phone, relationship,
                              profile_image, profile_completion
                              FROM Employee WHERE employee_id = @EmpId";

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@EmpId", employeeId);

                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    model = new EditProfileViewModel
                    {
                        EmployeeID = Convert.ToInt32(reader["employee_id"]),
                        FirstName = reader["first_name"].ToString(),
                        LastName = reader["last_name"].ToString(),
                        Email = reader["email"].ToString(),
                        PhoneNumber = reader["phone"] != DBNull.Value ? reader["phone"].ToString() : null,
                        DateOfBirth = reader["date_of_birth"] != DBNull.Value ? DateOnly.FromDateTime((DateTime)reader["date_of_birth"]) : null,
                        Address = reader["address"] != DBNull.Value ? reader["address"].ToString() : null,
                        EmergencyContactName = reader["emergency_contact_name"] != DBNull.Value ? reader["emergency_contact_name"].ToString() : null,
                        EmergencyContactPhone = reader["emergency_contact_phone"] != DBNull.Value ? reader["emergency_contact_phone"].ToString() : null,
                        EmergencyContactRelation = reader["relationship"] != DBNull.Value ? reader["relationship"].ToString() : null,
                        ProfileImagePath = reader["profile_image"] != DBNull.Value ? reader["profile_image"].ToString() : null,
                        ProfileCompletion = reader["profile_completion"] != DBNull.Value ? Convert.ToInt32(reader["profile_completion"]) : 0
                    };
                }
            }

            return model;
        }
    }
}