﻿using System;
using System.Collections.Generic;

namespace HRMSWebApplication.Models;

public partial class Notification
{
    public int NotificationId { get; set; }

    public string MessageContent { get; set; } = null!;

    public DateTime? Timestamp { get; set; }

    public string? Urgency { get; set; }

    public bool? ReadStatus { get; set; }

    public string NotificationType { get; set; } = null!;

    public virtual ICollection<EmployeeNotification> EmployeeNotifications { get; set; } = new List<EmployeeNotification>();
}
