﻿using System;
using System.Collections.Generic;

namespace HRMSWebApplication.Models;

public partial class ApprovalWorkflow
{
    public int WorkflowId { get; set; }

    public string WorkflowType { get; set; } = null!;

    public decimal? ThresholdAmount { get; set; }

    public string? ApproverRole { get; set; }

    public int? CreatedBy { get; set; }

    public string? Status { get; set; }

    public virtual ICollection<ApprovalWorkflowStep> ApprovalWorkflowSteps { get; set; } = new List<ApprovalWorkflowStep>();

    public virtual Employee? CreatedByNavigation { get; set; }
}
