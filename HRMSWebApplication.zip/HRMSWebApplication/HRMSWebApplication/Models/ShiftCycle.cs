﻿using System;
using System.Collections.Generic;

namespace HRMSWebApplication.Models;

public partial class ShiftCycle
{
    public int CycleId { get; set; }

    public string CycleName { get; set; } = null!;

    public string? Description { get; set; }

    public virtual ICollection<ShiftCycleAssignment> ShiftCycleAssignments { get; set; } = new List<ShiftCycleAssignment>();
}
